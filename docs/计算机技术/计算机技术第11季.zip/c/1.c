#include<stdio.h>
int main(int argc, char const *argv[])
{
    float a,b,c;
    scanf("%f,%f,%f",&a,&b,&c);
    printf("%.3f\n",a*b*c);
    return 0;
}
