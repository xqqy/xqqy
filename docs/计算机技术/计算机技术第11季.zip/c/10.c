#include<stdio.h>
#include<string.h>
int main(int argc, char const *argv[])
{
    char input[10086];
    scanf("%s",input);
    int middle=strlen(input)/2;
    for (size_t i = 0; i < middle; i++)
    {
        if(input[i]!=input[strlen(input)-i-1]){
            printf("不是\n");
            return 0;
        }
    }
    printf("是\n");
    
    return 0;
}
