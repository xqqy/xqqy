#include<stdio.h>
#include<string.h>
int main(int argc, char const *argv[])
{
    int a[]= {1,2,3,6,8,9,12,23,33};
    int input,flag=1;
    scanf("%d",&input);
    for (int i = 0; i < 9; i++)
    {
        if(a[i]>input && flag){
            printf("%d,",input);
            flag=0;
            i--;
        }else
        {
            printf("%d,",a[i]);
        }
        
    }
    if(flag)
        printf("%d,\n",input);
    else
        printf("\n");
    return 0;
}
