#include<stdio.h>
int main(int argc, char const *argv[])
{
    int a,b,t;
    scanf("%d%d",&a,&b);
    if(a>b){
        t=b;
        b=a;
        a=t;
    }
    while (a%b!=0)
    {
        t=a%b;
        a=b;
        b=t;
    }
    printf("%d\n",t);
    return 0;
}
