#include<stdio.h>
int main(int argc, char const *argv[])
{
    int day=0,ans=0;
    scanf("%d",&day);
    int now=0,i=1,d=0;
    while (now<day)
    {
        while (now<day && d<i)
        {
            ans+=i;
            d+=1;
            now+=1;
        }
        i++;
        d=0;
    }
    
    printf("%d\n",ans);
    
    return 0;
}
