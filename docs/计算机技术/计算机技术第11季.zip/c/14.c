#include<stdio.h>

int is7(int input);
int main(int argc, char const *argv[])
{
    int max;
    scanf("%d",&max);
    int ans=0;
    while (max>0)
    {
        if(!is7(max))
            ans+=1;
        max-=1;
    }
    printf("%d\n",ans);
    return 0;
}


int is7(int input)
{
    if(input%7==0)
        return 1;
    while (input>0)
    {
        if(input%10==7)
            return 1;
        input /= 10;
    }
    return 0;
}
