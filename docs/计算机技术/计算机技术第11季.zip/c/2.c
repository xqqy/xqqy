#include<stdio.h>
int main(int argc, char const *argv[])
{
    int a,b;
    scanf("%d,%d",&a,&b);
    if(a%b)
        puts("no");
    else
        puts("yes");
    return 0;
}
