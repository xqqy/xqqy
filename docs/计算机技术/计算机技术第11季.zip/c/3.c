#include<stdio.h>
int main(int argc, char const *argv[])
{
    float a;
    scanf("%f",&a);
    if(a<2880)
        printf("%.0f",a*0.48);
    else if(a<4800)
        printf("%.0f",1382.4+(a-2880)*0.53);
    else
        printf("%.0f",2400+(a-4800)*0.78);
    printf("\n");
    return 0;
}
