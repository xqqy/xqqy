#include<stdio.h>
#include<string.h>
int main(int argc, char const *argv[])
{
    char str[10086];
    int n;
    scanf("%s%d",str,&n);
    printf("%c\n",str[strlen(str)-n]);
    return 0;
}
