#include<stdio.h>
int main(int argc, char const *argv[])
{
    int text=67008;
    while (text%78!=0 || text%67!=0)
    {
        text += 10;
    }
    printf("%d\n",text);
    return 0;
}
//或
#include<stdio.h>
int main(int argc, char const *argv[])
{
    printf("67938\n");
    return 0;
}
