#include<stdio.h>
int main(int argc, char const *argv[])
{
    int n;
    scanf("%d",&n);
    float array[n],avg=0;
    int ans=0;
    for (int i = 0; i < n; i++)
    {
        scanf("%f",&array[i]);
        avg+= array[i]/n;
    }
    for (int i = 0; i < n; i++)
    {
        if(array[i]<avg)
            ans++;
    }
    printf("%d个\n",ans);
    return 0;
}
