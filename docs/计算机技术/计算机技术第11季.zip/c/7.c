/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

#include <stdio.h>
int main() {
    int num = 0, a[100];  // num表示闰年个数，a用于存放闰年

    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */

    int n;
    scanf("%d",&n);

    for (int i = 1601; i < 2015; i++)
    {
        if(i%400==0)
            a[num++]=i;
        else if(i%100!=0 && i%4==0)
            a[num++]=i;
    }
    

    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

    printf("%d,%d,%d\n", a[0], a[n - 1],a[num - 1]);  //输出第一个闰年、第n个闰年以及最后一个闰年
    return 0;
}

/* PRESET CODE END - NEVER TOUCH CODE ABOVE */