#include<stdio.h>
int main(int argc, char const *argv[])
{
    int k,ans=0;
    scanf("%d",&k);
    for (int i = 0; i <= k; i++)
    {
        for (int t = 0; t <= k; t++)
        {
            for (int l = 0; l <= k; l++)
            {
                if(i*3+t*2+l==50 && i+t+l==k){
                    printf("%d,%d,%d\n",i,t,l);
                    ans++;
                }
            }
            
        }
        
    }
    printf("共%d种可能\n",ans);
    
    return 0;
}
