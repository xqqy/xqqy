#include<stdio.h>
int iszhi(int a){
    for (int i = 2; i < a; i++)
    {
        if(a%i==0)
            return 0;
    }
    return 1;
}
int main(int argc, char const *argv[])
{
    int a,ans=1,i;
    scanf("%d",&a);
    for (i =2; ans <= a;i++)
    {
        if(iszhi(i))
            ans++;
    }
    printf("%d\n",--i);
    
    return 0;
}
