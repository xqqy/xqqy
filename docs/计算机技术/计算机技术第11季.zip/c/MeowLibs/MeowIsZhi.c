// MeowIsZhi lib start;Powered by xqqy!
int MeowIsZhi(int i) {
    int t;
    for (t = 2; t < i; t++) {
        if (!(i % t)) {  //不是质数
            return 0;
        }
    }
    return 1;
}
// MeowIsZhi lib end;Powered by xqqy