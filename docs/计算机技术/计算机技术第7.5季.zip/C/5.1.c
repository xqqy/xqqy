//Powered by xqqy  
#include<stdio.h>
int main(){
    printf("* \n* * \n* * * \n* * * * \n* * * * * \n");
    int a;
    if(a=0){
        printf("fuck");
    }
    return 0;
}