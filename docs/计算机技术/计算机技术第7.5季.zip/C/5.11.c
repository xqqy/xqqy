//Powered by xqqy
#include <stdio.h>
int iszhi(int i)
{
    int t;
    for (t = 2; t < i; t++)
    {
        if (!(i % t))
        { //不是质数
            return 0;
            break;
        }
    }
    return 1;
}
int main()
{
    int a, t=0,i;
    scanf("%d", &a);

    for (i = 2; t < a; i++)
    {
        if (iszhi(i)){
            t++;
        }
    }
    printf("%d\n",i-1);
    return 0;
}