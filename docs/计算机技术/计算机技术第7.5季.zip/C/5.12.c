//Powered by xqqy
#include <stdio.h>
int main()
{
    int a, b, c;
    scanf("%d%d%d", &a, &b, &c);
    for (int i = 3; i < 101; i++)
    {
        if(!((i - a) % 3) &&!((i - b) % 5) && !((i - c) % 7)){
            printf("%d\n",i);
            return 0;
        }
    }
    printf("无解\n");
    return 0;
}