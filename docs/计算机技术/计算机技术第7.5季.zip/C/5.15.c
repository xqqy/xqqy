//Powered by xqqy
#include <stdio.h>
int main()
{
    int a=100;
    //scanf("%d", &a);
    int ans=0;
    for (int man = 0; man <= 40; man++)
    {
        for (int woman = 0; woman <= 50; woman++)
        {
            for (int child = 0; child <= 100; child++)
            {
                if(3*man+2*woman+0.5*child==100.0 && man+woman+child==a){
                    printf("%d,%d,%d\n",man,woman,child);
                    ans++;
                }
            }
        }
    }
    //printf("共%d种可能\n",ans);
    
    return 0;
}