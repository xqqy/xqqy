//Powered by xqqy
#include <stdio.h>
#define true 1
#define false 0
int isrun(int i);
int main()
{
    int n,ans=1604;
    scanf("%d",&n);
    if(n==1){
        printf("第1个闰年是1604\n");
        return 0;
    }
    for (int i = 1; i < n; i++)
    {
        ans += 4;
        if(ans%100==0 && ans%400!=0){
            ans += 4;
        }
    }
    printf("第%d个闰年是%d\n",n,ans);
    return 0;
}
int isrun(int a){  
    if(!(a%400)){  
        return true;
    }else if(!(a%100)){  
        return false;
    }else if(!(a%4)){  
        return true;
    }else{  
        return false;
    }  
} 