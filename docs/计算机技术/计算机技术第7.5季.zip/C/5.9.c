//Powered by xqqy
#include <stdio.h>
#define true 1
#define false 0
int isrun(int i);
int main()
{
    int n;
    scanf("%d",&n);
    n++;
    char list[100][100];
    int howmuch=1;
    for (int i = 0; i < n/2; i++)
    {
        for (int t = 0; t < howmuch; t++)
        {
            list[i][t]='*';
        }
        howmuch+=2;
    }
    int length;
    for (length = 0; list[length][0]=='*'; length++)
    {
        printf("%s\n",list[length]);
    }
    for (int i = length; i > 0; i--)
    {
        printf("%s\n",list[i-1]);
    }
    
    
    return 0;
}