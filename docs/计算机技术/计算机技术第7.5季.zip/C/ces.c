#include<stdio.h>   
int main()  
{  
    int i,j,m,n,count=0,a;  
    scanf("%d%d",&m,&n);  
    for(i=0;i<=m;i++)  
    {  
        for(j=0;j<=m;j++)  
        {  
           if((i+j==m)&&((8*i)-(3*j)==n))  
            {  
            count==count+1;
            a==i;
         }
  } 
 }
 if(count==0)
 {
 printf("无解决方案\n");
 }
 else
 {
  if(count!=0)
  {
        printf("买A种票的人数=%d\n",a); 
 } 
  } 
    return 0;  
}   