//Powered by xqqy
#include <stdio.h>
#define true 1
#define false 0
int isrun(int i);
int main()
{
    int a, b, ans = 0,i;
    scanf("%d%d", &a, &b);
    for (; a <= b; a++)
    {
        i=a;
        while (i > 0)
        {
            if (i % 10 == 3)
            {
                ans++;
                break;
            }
            else
            {
                i /= 10;
            }
        }
    }
    printf("%d\n",ans);

    return 0;
}