//Powered by xqqy  
#include<stdio.h>
int main(){
    printf("     A\n    ABC\n   ABCDE\n  ABCDEFG\n ABCDEFGHI\nABCDEFGHIJK\n");
    return 0;
}