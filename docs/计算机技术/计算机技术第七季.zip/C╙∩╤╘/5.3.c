//Powered by xqqy  
#include<stdio.h>
int flag=0;
void Meowprint(int a);
int main(){
    int a;
    scanf("%d",&a);
    while(a%3){
        Meowprint(a);
        a++;
    }
    do
    {
        Meowprint(a+1);
        Meowprint(a+2);
        a+=3;
    } while (a<200);
    if(flag%5){
        printf("\n");
    }
    return 0;
}

inline void Meowprint(int a){
    extern int flag;
    flag++;
    if(flag%5){
        printf("%d,",a);
    }else{
        printf("%d,\n",a);
    }
}