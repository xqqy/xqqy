//Powered by xqqy
#include <stdio.h>
int main()
{
    int k;
    scanf("%d", &k);
    k *= 10;
    int ans=0,y10=0,y5=0,y1=0;
    for (y10 = 0; y10 <= 40; y10++)
    {
        for (y5 = 0; y5 <= 40; y5++)
        {
            for (y1 = 0; y1 <= 40; y1++)
            {
                if(y10*10+y5*5+y1*1==k && y10+y5+y1==40){
                    ans++;
                }
            }
        }
    }
    printf("%d\n",ans);
    return 0;
}