//Powered by xqqy
#include <stdio.h>
int main()
{
    int k;
    scanf("%d", &k);
    if(k<=2){
        printf("1\n");
        return 0;
    }
    int a=1,b=1;
    for (int i = 1; i*2 < k; i++)
    {
        a+=b;
        b+=a;
    }
    if(k%2){
        printf("%d\n",a);
    }else{
        printf("%d\n",b);
    }
    
    return 0;
}