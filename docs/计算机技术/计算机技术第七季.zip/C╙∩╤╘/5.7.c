//Powered by xqqy
#include <stdio.h>
int iszhi(int i);
int main()
{
    int ans=0;
    for (int i = 100; i <= 200; i++)
    {
        /* code */
        if(iszhi(i)){
            ans++;
        }
    }
    printf("%d个\n",ans);
    return 0;
}
inline int iszhi(int i){  
    int t;  
    for(t=2;t<i;t++){  
            if(!(i%t)){//不是质数  
                return 0;  
                break;  
            }
    }  
    return 1;  
} 