//Powered by xqqy
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
int main(){
    srand(time(NULL));
    int a=0,b=1;
    while (a!=b)
    {
        a=rand()%100;
        scanf("%d",&b);
    }
    return 0;
}