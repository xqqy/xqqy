//Powered by xqqy
#include<stdio.h>
int main(){
    int i;
    float a,sum;
    for(i=0;i<10;i++){
        scanf("%f",&a);
        sum +=a;
    }
    printf("%.0f\n%.1f\n",sum,sum/10);
    
    return 0;
}