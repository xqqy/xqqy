//Powered by xqqy
#include<stdio.h>
int main(){
    int a,b;
    scanf("%d%d",&a,&b);
    printf("%d\n",(a+b-1)*(b-a)/2);
    
    return 0;
}