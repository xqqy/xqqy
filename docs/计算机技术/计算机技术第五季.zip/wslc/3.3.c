//Powered by xqqy
#include<stdio.h>
int main(){
    int a,b;
    scanf("%d%d",&a,&b);
    if(!(a%2)){
        a +=1;
    }
    if(!(b%2)){
        b -=1;
    }
    printf("%d\n",(a+b)*(b-a)/4);
    
    return 0;
}