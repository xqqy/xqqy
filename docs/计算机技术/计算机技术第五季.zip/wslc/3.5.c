//Powered by xqqy
#include<stdio.h>
int main(){
    int a;
    scanf("%d",&a);
    if(a<2){//阻止不能创建数列的问题，好像不必要。。。
        if(a==1){
            printf("1\n");
        }else{
            printf("-1\n");
        }
    return 0;
    }
    //判断最后一位是偶数还是奇数
    if(a%2){
        //奇数，公式为(n+1)/2
        printf("%d\n",(a+1)/2);
    }else{
        //偶数，公式为-n/2
        printf("%d\n",-a/2);
    }
    return 0;
}