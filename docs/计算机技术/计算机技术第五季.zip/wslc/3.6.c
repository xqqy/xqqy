//Powered by xqqy
#include<stdio.h>
int main(){
    int a,b;
    scanf("%d%d",&a,&b);
    while(!(a%3)){
        a++;
    }
    while(!(b%3)){
        b--;
    }
    printf("%d\n",(b-a)/3+1);
    return 0;
}