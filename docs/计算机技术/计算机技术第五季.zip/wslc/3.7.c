//Powered by xqqy
#include<stdio.h>
int main(){
    int a,i=0,sumz=0,sumf=0;
    for(i=0;i<10;i++){
        scanf("%d",&a);
        if(a>0){
            sumz+=a;
        }else{
            sumf+=a;
        }
    }
    printf("%d\n%d\n",sumz,sumf);
    return 0;
}