//Powered by xqqy
#include<stdio.h>
int main(){
    int a;
    scanf("%d",&a);
    int ans=1;
    for(;a>0;a--){
        ans *= a;
    }
    printf("%d\n",ans);
    return 0;
}