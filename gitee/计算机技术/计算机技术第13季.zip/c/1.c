#include <stdio.h>    
int main(int argc, char** argv)    
{    
    float a,b,h;    
    scanf("%f%f%f",&a,&b,&h);    
    printf("%0.2f\n",(a+b)*h/2);    
    return 0;    
}    