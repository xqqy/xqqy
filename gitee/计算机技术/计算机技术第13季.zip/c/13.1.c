    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
     
    #include<stdio.h>  
    struct goods  
    {  
        char name[20];  
        float price;  
        int amount;  
    };   
    int main()  
    {  
        struct goods fruit[5]={{"pear",5.18,35},{"orange",3.80,80},{  
        "banana",7.88,55},{"lemon",6.5,42},{"strawberry",15.5,50}};  
      
    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */  
    int input,ans=0;
    scanf("%d",&input);
    for (int i = 0; i < 5; i++)
    {
        if(fruit[i].amount<input){
            printf("%s,%.1f,%d\n",fruit[i].name,fruit[i].price,fruit[i].amount);
            ans++;
        }
    }
    if(ans==0)
        printf("无\n");
    return 0;
    }