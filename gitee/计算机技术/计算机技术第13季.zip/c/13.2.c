/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
 
#include<stdio.h>     
int main()  
{  
    struct employee  
    {     
        char name[20];  
        char ID[10];  
        int age;  
        float salary;  
    }staff[6];  
  
/* PRESET CODE END - NEVER TOUCH CODE ABOVE */ 
int max=0;
for (int i = 0; i < 6; i++)
{
    scanf("%s%s%d%f",staff[i].name,staff[i].ID,&staff[i].age,&staff[i].salary);
    if(staff[max].salary<staff[i].salary)
        max=i;
}
printf("最高工资:%.1f,姓名:%s,工号:%s\n",staff[max].salary,staff[max].name,staff[max].ID);
return 0;
}
