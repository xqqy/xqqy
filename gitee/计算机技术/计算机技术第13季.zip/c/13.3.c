/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

#include <stdio.h>
struct emp {
    int id;
    char name[10];
    int salary;
} e[6];

/* PRESET CODE END - NEVER TOUCH CODE ABOVE */
int main(int argc, char const* argv[]) {
    int max = 0;
    struct emp staff[6];
    for (int i = 0; i < 6; i++) {
        scanf("%d%s%d", &staff[i].id, staff[i].name, &staff[i].salary);
        if (staff[max].salary > staff[i].salary)
            max = i;
    }
    printf("%d %s %d\n",staff[max].id, staff[max].name, staff[max].salary);
    return 0;
}