//正在直播做题~
//欢乐东方歌单

    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
     
    #include <stdio.h>  
    struct btbucode//定义结构体btbucode  
    {  
        int n;          
        char pn[50];   
    };  
    struct btbucode code[]={{11, "cailiao"},{12, "caiji"},{13, "shang"},{14, "jingji"},{15, "jixin"},  
        {16, "shipin"},{17, "lixueyuan"},{18, "fama"},{19, "waiguoyu"},{20, "yishuchuanmei"},  
        {95, "gonghui"},{96,"jiaowuchu"},{97,"renshichu"},{98,"kejichu"},{99,"xiaoban"}};//定义结构体数组code并初始化  
      
//共15个
      int main(int argc, char const *argv[])
      {
          int input;
          scanf("%d",&input);
          for (int i = 0; i < 15; i++)
          {
              if(code[i].n==input){
                  printf("%s\n",code[i].pn);
                  return 0;
              }
          }
          printf("没找到\n");
          return 0;
      }
      
    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */  