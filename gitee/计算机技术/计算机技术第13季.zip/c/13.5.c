    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
     
    #include <stdio.h>  
    struct student  
    {  
       char name[20];  
       float mathScore;  
    };   
    int main()  
    {  
        int i;  
        struct student score[15];  
        for(i=0;i<15;i++)//从键盘输入15个学生姓名以及成绩        
            scanf("%s%f",score[i].name,&score[i].mathScore);  
      
    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */  

        float sum=0;
        for (int i = 0; i < 15; i++)
        {
            sum+=score[i].mathScore;
        }
        printf("平均分：%.2f",sum/15.0);
    }
