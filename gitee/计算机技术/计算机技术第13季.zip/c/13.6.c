/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
 
#include <stdio.h>  
struct student  
{  
   char name[20];  
   float mathScore;  
};   
int main()  
{  
    int i;  
    struct student score[15];  
    for(i=0;i<15;i++)//从键盘输入15个学生姓名以及成绩        
        scanf("%s%f",score[i].name,&score[i].mathScore);  
  
/* PRESET CODE END - NEVER TOUCH CODE ABOVE */
    int MaxNum=0;
    for (int i = 1; i < 15; i++)
    {
        if(score[MaxNum].mathScore<score[i].mathScore)
            MaxNum=i;
    }
    printf("最高分:%s %.2f\n",score[MaxNum].name,score[MaxNum].mathScore);
    return 0;
    
}