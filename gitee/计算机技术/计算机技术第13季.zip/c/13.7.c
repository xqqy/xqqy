    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
     
    #include <stdio.h>  
    struct student  
    {  
       char name[20];  
       float mathScore;  
    };   
    int main()  
    {  
        int i;  
        float a;  
        struct student score[15];  
        for(i=0;i<15;i++)//从键盘输入15个学生姓名以及成绩        
            scanf("%s%f",score[i].name,&score[i].mathScore);  
        scanf("%f",&a);//输入要查找的成绩  
      
    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */  
    for (int i = 0; i < 15; i++)
          {
              if(score[i].mathScore==a){
                  printf("%s %.2f\n",score[i].name,score[i].mathScore);
                  return 0;
              }
          }
          printf("没找到\n");
    }