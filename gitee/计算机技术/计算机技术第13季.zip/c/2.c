#include<stdio.h>
int main(int argc, char const *argv[])
{
    int a;
    scanf("%d",&a);
    if (a>100)
        printf("成绩错误\n");
    else if(a>=60)
        printf("通过\n");
    else
        printf("未通过\n");
    
    return 0;
}
