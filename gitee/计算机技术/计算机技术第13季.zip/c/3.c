    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
     
    #include<stdio.h>   
    int main()   
    {  
        int n,a[20]={1,2},i;  
        scanf("%d",&n);  
      
    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */  

        
   int b[]={1,2,3,1,4,3,7,4,11,7,18,11,29,18,47,29,76,47,123,76};
   for (int i = 0; i < 20; i++)
   {
       a[i]=b[i];
   }
   

    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
      
    for(i=0;i<n;i++)//输出前n项  
        printf("%d,",a[i]);  
      printf("\n");  
      return 0;  
    }  
      
    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */  