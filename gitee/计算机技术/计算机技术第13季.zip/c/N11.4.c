#include <stdio.h>
int main(int argc, char const* argv[]) {
    int pre = 0,prenow, now = 0, forward = 0, min = 1486618625, flag = 0;
    for (int i = 0; i < 10; i++) {
        prenow = now;
        scanf("%d", &now);
        if (flag == 1) {
            forward = now;
            flag = 0;
        }
        if (min > now) {
            pre=prenow;
            min = now;
            flag = 1;
        }
    }
    printf("%d,%d,\n", pre, forward);
    return 0;
}
