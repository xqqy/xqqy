#include<stdio.h>
typedef
int main(int argc, char const *argv[])
{
    
    return 0;
}
