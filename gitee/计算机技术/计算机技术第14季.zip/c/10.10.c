#include<stdio.h>
int isinb(int array[10],int input){
    for (int i = 0; i < 10; i++)
    {
        if(array[i]==input)
            return 1;
    }
    return 0;
}
int main(int argc, char const *argv[])
{
    int a[10],b[10];
    for (int i = 0; i < 10; i++)
    {
        scanf("%d",&a[i]);
    }
    for (int i = 0; i < 10; i++)
    {
        scanf("%d",&b[i]);
    }

    for (int i = 0; i < 10; i++)
    {
        if(isinb(b,a[i])==0){
            printf("%d,",a[i]);
        }
    }
    printf("\n");
    return 0;
}
