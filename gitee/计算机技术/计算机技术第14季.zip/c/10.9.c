#include<stdio.h>
int jie(const int inp){
    int ans=1;
    for (int i = 1; i <= inp; i++)
    {
        ans *= i;
    }
    return ans;
}
int main(){
    int m,n;
    scanf("%d%d",&m,&n);
    printf("%d\n",jie(n)/jie(m)/jie(n-m));
    return 0;
}