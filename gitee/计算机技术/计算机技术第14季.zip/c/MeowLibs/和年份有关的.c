#include<stdio.h>  
int isrun(int year){  //判断是否为闰年
    if(year%400==0){  
        return 1;  
    }else if(year%100==0){  
        return 0;  
    }  
    else if(year%4==0){  
        return 1;  
    }else{  
        return 0;  
    }  
}  
  
int MonthDayNoRun[12]={31,28,31,30,31,  
                      30,31,31,30,31,  
                      30,31};  //不是闰年的每个月的天数，使用时记得月份要-1
int MonthDayRun[12]={31,29,31,30,31,  
                      30,31,31,30,31,  
                      30,31};  //是闰年的每个月的天数，使用时记得月份要-1