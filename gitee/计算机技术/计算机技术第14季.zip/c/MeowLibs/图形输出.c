#include <stdio.h>
void MeowPrintline(
    unsigned int count,
    const char*
        what) {  //输出整整一行某东西,count是输出多少个，what是输出什么字符
    for (size_t i = 0; i < count; i++) {
        printf("%s", what);
    }
    printf("\n");
    return;
}
void MeowPrintStart(
    unsigned int count,
    const char*
        what) {  //只输出头和尾巴，count是中间的空格数量，what是头和尾巴的样式；长度小于2的话会什么都不输出
    if (count < 2)
        return;
    count -= 2;
    printf("%s", what);
    for (size_t i = 0; i < count; i++) {
        printf(" ");
    }
    printf("%s", what);
    printf("\n");
    return;
}
void MeowPrintMiddle(
    unsigned int SpaceCountStart,
    unsigned int SpaceCountEnd,
    unsigned int CharCount,
    const char*
        what) {  //居中输出；SpaceCountStart是开头空格的长度，SpaceCountEnd是末尾空格的长度，CharCount是字符的长度，what是头和尾巴的样式；
    for (size_t i = 0; i < SpaceCountStart; i++) {
        printf(" ");
    }
    for (size_t i = 0; i < CharCount; i++) {
        printf("%s", what);
    }
    for (size_t i = 0; i < SpaceCountEnd; i++) {
        printf(" ");
    }
    printf("\n");
    return;
}
