/*请直接使用ctype.h中的
tolower
和
touper函数
例子：*/
#include<stdio.h>
#include<ctype.h>
int main(int argc, char const *argv[])
{
    printf("%c\n",toupper('a'));
    printf("%c\n",tolower('A'));
    return 0;
}
/*
同时，Ctype库中还包含了以下函数
 1	int isalnum(int c)
该函数检查所传的字符是否是字母和数字。
2	int isalpha(int c)
该函数检查所传的字符是否是字母。
3	int iscntrl(int c)
该函数检查所传的字符是否是控制字符。
4	int isdigit(int c)
该函数检查所传的字符是否是十进制数字。
5	int isgraph(int c)
该函数检查所传的字符是否有图形表示法。
6	int islower(int c)
该函数检查所传的字符是否是小写字母。
7	int isprint(int c)
该函数检查所传的字符是否是可打印的。
8	int ispunct(int c)
该函数检查所传的字符是否是标点符号字符。
9	int isspace(int c)
该函数检查所传的字符是否是空白字符。
10	int isupper(int c)
该函数检查所传的字符是否是大写字母。
11	int isxdigit(int c)
该函数检查所传的字符是否是十六进制数字。
*/