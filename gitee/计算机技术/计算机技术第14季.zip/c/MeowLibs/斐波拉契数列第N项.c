//Powered by xqqy  
#include <stdio.h>  
int MeowFBLQ(int k)  
{  
    if(k<=2){  
        printf("1\n");  
        return 0;  
    }  
    int a=1,b=1;  
    for (int i = 1; i*2 < k; i++)  
    {  
        a+=b;  
        b+=a;  
    }  
    if(k%2){  
        return a;
    }else{  
        return b;
    }  
      
    return 0;  
}