#include <stdio.h>
int MeowMaxPublicYue(int a,int b) {//计算最大公约数的函数，a和b是两个输入的整数
    int  t;
    if (a > b) {
        t = b;
        b = a;
        a = t;
    }
    while (a % b != 0) {
        t = a % b;
        a = b;
        b = t;
    }
    return t;
}