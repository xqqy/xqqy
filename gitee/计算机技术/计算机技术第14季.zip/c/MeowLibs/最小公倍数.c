// powered by xqqy
#include <stdio.h>
#include <stdlib.h>

// MeowArray lib start;Powered by xqqy!
typedef struct
    MeowArray  //双向链表技术！！!(isfirst和isend更方便喵看它是不是越界！)
{
    struct MeowArray* forward;
    struct MeowArray* back;
    int data;
    int isfirst;
    int isend;
} MeowArray;

//默认返回第一个节点
MeowArray* MeowArrayNew(const int first)  //创建第一个MeowArray节点
{
    MeowArray* node;                               //当前节点
    node = (MeowArray*)malloc(sizeof(MeowArray));  //输入第一个节点
    node->isfirst = 1;
    node->isend = 1;
    node->data = first;

    return node;
}

MeowArray* MeowArrayAppend(MeowArray* first,
                           const int what) {  //在末尾插入新变量
    MeowArray* node;
    node = first;
    while (!node->isend)  //获取末尾节点
    {
        node = node->back;
    }

    //末尾节点
    MeowArray* forward;
    forward = node;                                //前一个结点
    node = (MeowArray*)malloc(sizeof(MeowArray));  // new一个新节点
    node->data = what;                             //输入数据
    node->forward = forward;                       //更改指针
    forward->back = node;
    node->isfirst = 0;  //更改flag
    node->isend = 1;
    forward->isend = 0;

    return first;
}

int MeowArrayIndexOf(
    MeowArray* node,
    const int what) {  //获取变量第一次出现在数组内的位置，没有就返回-1
    while (!node->isfirst) {  //确保为开始节点
        node = node->forward;
    }

    if (node->data == what)  //只有一个长度的第一个节点是
        return 0;

    unsigned long long i = 0;
    for (; !node->isend; i++) {
        if (node->data == what)
            return --i;
        node = node->back;
    }
    if (node->data == what)  //最后一个节点是
        return i;

    else
        return -1;
}

MeowArray* MeowArrayDel(MeowArray* node, const int pos) {
    while (!node->isfirst) {  //确保为开始节点
        node = node->forward;
    }

    for (unsigned long long i = 0; i < pos; i++) {  //获取需要被删除的节点
        node = node->back;
    }

    if (node->isend && node->isfirst) {  //只有一个长度的数组
        free(node);
        return NULL;
    } else if (!node->isfirst && !node->isend) {  //中间的就把他们连起来
        MeowArray *forward, *back;
        forward = node->forward;
        back = node->back;
        free(node);  //你自由啦（x
        //更改指针
        forward->back = back;
        back->forward = forward;
    } else if (node->isend) {
        node = node->forward;
        free(node->back);
        node->isend = 1;  //所有isend的时候，back指针用了就是错……

    } else {
        node = node->back;
        free(node->forward);
        node->isfirst = 1;  //所有isfirst的时候，forward指针用了就是错……
    }

    //返回第一个结点
    while (!node->isfirst) {
        node = node->forward;
    }
    return node;
}
// MeowArray lib end;Powered by xqqy!
// MeowIsZhi lib start;Powered by xqqy!
int MeowIsZhi(int i) {
    int t;
    for (t = 2; t < i; t++) {
        if (!(i % t)) {  //不是质数
            return 0;
        }
    }
    return 1;
}
// MeowIsZhi lib end;Powered by xqqy

int MeowMinPublicBei(int a,int b) {//计算最小公倍数的函数，a和b是两个输入的整数
    MeowArray *ListA, *ListB, *ListShared;
    int FlagA = 0, FlagB = 0, FlagShared = 0;  //检查是否需要初始化数组
    for (int i = 2; i <= a; i++) {  //检查a的质因数，并将其存入ListA
        if (a % i == 0 && MeowIsZhi(i)) {
            if (!FlagA) {  //检查是否有过初始化
                ListA = MeowArrayNew(i);
                FlagA = 1;
            } else {
                MeowArrayAppend(ListA, i);
            }
            //重头开始找最小的质因数
            a = a / i;
            i = 1;
        }
    }
    for (int i = 2; i <= b; i++) {
        if (b % i == 0 && MeowIsZhi(i)) {
            if (FlagA &&
                MeowArrayIndexOf(ListA, i) !=
                    -1) {  //在ListA里面有过了，需要把其删除并存入Shared
                ListA = MeowArrayDel(ListA, MeowArrayIndexOf(ListA, i));
                if (ListA == NULL)  //如果把数组A删光了
                    FlagA = 0;
                if (!FlagShared) {  //检查是否有过初始化
                    ListShared = MeowArrayNew(i);
                    FlagShared = 1;
                } else {
                    MeowArrayAppend(ListShared, i);
                }
            } else {           // ListA里面没有，加入ListB
                if (!FlagB) {  //检查是否有过初始化
                    ListB = MeowArrayNew(i);
                    FlagB = 1;
                } else {
                    MeowArrayAppend(ListB, i);
                }
            }
            //重头开始找最小的质因数
            b = b / i;
            i = 1;
        }
    }

    //遍历ListA、ListB、ListShared
    int ans = 1;
    if (FlagA) {
        while (!ListA->isend) {
            ans *= ListA->data;
            ListA = ListA->back;
        }
        ans *= ListA->data;
    }
    if (FlagB) {
        while (!ListB->isend) {
            ans *= ListB->data;
            ListB = ListB->back;
        }
        ans *= ListB->data;
    }
    if (FlagShared) {
        while (!ListShared->isend) {
            ans *= ListShared->data;
            ListShared = ListShared->back;
        }
        ans *= ListShared->data;
    }
    return ans;
}
