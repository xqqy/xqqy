#include<stdio.h>

int main(int argc, char const *argv[])
{
    int a;
    scanf("%d",&a);
    printf("%d\n",a*a);
    return 0;
}
