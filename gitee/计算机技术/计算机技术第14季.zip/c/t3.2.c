#include<stdio.h>
int main(int argc, char const *argv[])
{
    int a;
    scanf("%d",&a);
    if(a>5)
        printf("%d\n",a*12);
    else
        printf("%d\n",a*10);
    return 0;
}
