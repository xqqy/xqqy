#include<stdio.h>
int main(int argc, char const *argv[])
{
    int red=0,white=0,black=0;
    int Rlimit=3,Wlimit=3,Blimit=6;
    int n,ans=0;
    scanf("%d",&n);
    if(Rlimit>n)
        Rlimit=n;
    if(Wlimit>n)
        Wlimit=n;
    if(Blimit>n)
        Blimit=n;
    
    while (red<=Rlimit)
    {
        while (white<=Wlimit)
        {
            while (black<=Blimit)
            {
                if(red+white+black==n){
                    printf("%d,%d,%d\n",red,white,black);
                    ans++;
                }
                black++;
            }
            black=0;
            white++;
        }
        white=0;
        red++;
    }
    printf("%d种\n",ans);
    return 0;
}
