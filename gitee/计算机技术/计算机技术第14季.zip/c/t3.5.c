#include<stdio.h>
int main(int argc, char const *argv[])
{
    int a[10];
    for (int i = 0; i <  10; i++)
    {
        scanf("%d",&a[i]);
    }
    for (int i = 10; i > 0; i--)
    {
        for (int t = 1; t < i; t++)
        {
            if(a[t-1]>a[t]){
                int temp=a[t-1];
                a[t-1]=a[t];
                a[t]=temp;
            }
        }
        
    }
    printf("%d\n%d\n%d\n%d\n%d\n",a[0]+a[9],a[1]+a[8],a[2]+a[7],a[3]+a[6],a[4]+a[5]);
    return 0;
}
