#include <stdio.h>
int ishe(int a)
{
    if(a<10)
        return 0;
    int he = 0,ge;
    ge = a % 10;
    a /= 10;
    while (a > 0)
    {
        he += a % 10;
        a /= 10;
    }
    if(he==ge)
        return 1;
    else
        return 0;
}

int main()
{
    int count, ans=0;
    scanf("%d", &count);
    for (int i = 0; i < count; i++)
    {
        if (ishe(i)==1)
            ans = ans + 1;
    }
    printf("%d\n", ans);
    return 0;
}