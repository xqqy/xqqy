/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

#include <stdio.h>
int fun(int m)  //判断是否素数
{
    int i;
    for (i = 2; i < m; i++)
        if (m % i == 0)
            break;
    if (i == m)
        return 1;
    else
        return 0;
}

/* PRESET CODE END - NEVER TOUCH CODE ABOVE */

int main(){
    int input;
    scanf("%d",&input);
    while (!fun(input) || !fun(input-2))
    {
        input--;
    }
    printf("%d,%d,",input-2,input);
    return 0;
}