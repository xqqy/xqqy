#include<stdio.h>
int isrun(int year){
    if(year%400==0){
        return 1;
    }else if(year%100==0){
        return 0;
    }
    else if(year%4==0){
        return 1;
    }else{
        return 0;
    }
}

int MonthDayNoRun[12]={31,28,31,30,31,
                      30,31,31,30,31,
                      30,31};
int MonthDayRun[12]={31,29,31,30,31,
                      30,31,31,30,31,
                      30,31};

int main(){
    int year,month,day;
    scanf("%d%d%d",&year,&month,&day);
    if(isrun(year)==1){//如果是闰年
        if(MonthDayRun[month-1]==day){//如果是最后一天
            if(month==12){
                year+=1;
                month=1;
                day=1;
            }else{
                month+=1;
                day=1;
            }
        }else{
            day+=1;
        }
    }else{
        if(MonthDayNoRun[month-1]==day){//如果是最后一天
            if(month==12){
                year+=1;
                month=1;
                day=1;
            }else{
                month+=1;
                day=1;
            }
        }else{
            day+=1;
        }
    }
    printf("第二天%d-%d-%d\n",year,month,day);
    return 0;
}