#include<stdio.h>
int MeowPrintline(unsigned int count,const char* what){//输出整整一行某东西
    for (size_t i = 0; i < count; i++)
    {
        printf("%s",what);
    }
    printf("\n");
    return 1;
}
int MeowPrintStart(unsigned int count,const char* what){//只输出头和尾巴
    if(count<2)
        return 0;
    count-=2;
    printf("%s",what);
    for (size_t i = 0; i < count; i++)
    {
        printf(" ");
    }
    printf("%s",what);
    printf("\n");
    return 1;
}
int main(int argc, char const *argv[])
{
    int count;
    scanf("%d",&count);
    MeowPrintline(count,"* ");
    for (size_t i = 0; i < count-2; i++)
    {
        MeowPrintStart(count*2-2,"* ");
    }
    MeowPrintline(count,"* ");
    return 0;
}
