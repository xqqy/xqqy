// Powered by xqqy
#include <stdio.h>
int main() {
    int i, n;
    scanf("%d", &n);
    if (n % 4 == 0) {
        printf("绿\n");
    }
    if (n % 4 == 1) {
        printf("红\n");
    }
    if (n % 4 == 2) {
        printf("黄\n");
    }
    if (n % 4 == 3) {
        printf("蓝\n");
    }
    return 0;
}