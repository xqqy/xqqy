//powered by xqqy
#include<stdio.h>
int main(int argc, char const *argv[])
{
    int array[8];
    for (int i = 0; i < 8; i++)
    {
        scanf("%d",&array[i]);
    }
    
    array[sizeof(array)/sizeof(array[0])-1]=0;
    for (int i = 0; i < sizeof(array)/sizeof(array[0])-2; i++)
    {
        printf("%d ",array[i]);
    }
    printf("%d\n",array[sizeof(array)/sizeof(array[0])-2]);
    return 0;
}
