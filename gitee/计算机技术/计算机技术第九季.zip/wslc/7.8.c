    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
     
    #include<stdio.h>  
    int main()  
    {  
     int a[10],i,n;  
     scanf("%d",&n);//输入n  
     for(i=0;i<n;i++)//输入数组  
         scanf("%d",&a[i]);  
      
    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */

int temp;
temp=a[0];
a[0]=a[n-1];
a[n-1]=temp;

for (int i = 0; i < n; i++)
{
    printf("%d,",a[i]);
}
printf("\n");

    }