//powered by xqqy
#include<stdio.h>
int main(int argc, char const *argv[])
{
    int score;
    scanf("%d",&score);
    if(score>=90)
        printf("优秀\n");
    else if(score>=80)
        printf("良好\n");
    else if(score>=60)
        printf("通过\n");
    else
        printf("不通过\n");
    return 0;
}
