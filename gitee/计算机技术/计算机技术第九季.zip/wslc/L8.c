//powered by xqqy
#include<stdio.h>
int main(int argc, char const *argv[])
{
    int count,ans=1;
    scanf("%d",&count);
    for (int i = 2; i <= count; i++)
    {
        ans+= i*i;
    }
    printf("%d\n",ans);
    return 0;
}
