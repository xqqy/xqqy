//powered by xqqy
#include<stdio.h>
#include<math.h>
int main(int argc, char const *argv[])
{
    double x,ans=0;
    int flag=1;
    scanf("%lf",&x);
    for (int i = 1; i <= 10; i++)
    {
        ans+=pow(x,i)/i*flag;
        flag*=-1;
    }
    printf("%.4lf\n",ans);
    return 0;
}
