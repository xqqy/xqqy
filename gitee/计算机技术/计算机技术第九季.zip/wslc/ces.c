#include<stdio.h>   
int main()  
{  
    int i,j,tmp,list[50],n;  
    scanf("%d",&n);/*输入实际个数*/  
    for(i=0;i<n;i++)/*输入数组元素*/  
       scanf("%d",&list[i]);  
  
/* PRESET CODE END - NEVER TOUCH CODE ABOVE */  
for(i=0;i<n;i++)
		for(j=0;j<n-i-1;j++)
		{
			if(list[j]>list[j+1])
			{
				tmp=list[j];
				list[j]=list[j+1];
				list[j+1]=tmp;
			}
		}
/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
  
for(i=0;i<n; i++)//输出排好序的数组元素  
    printf("%d,",list[i]);   

printf("\n"); 
return 0;  
} 