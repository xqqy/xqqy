//Powered by Xqqy
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main(int argc, char** argv){
    int a;
    scanf("%d",&a);
    printf("%d\n",abs(a));
    return 0;
}
