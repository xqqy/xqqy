//Powered by Xqqy
#define pies 4.186666666
#define trb(x) ((x) * (x) * (x))
#include<stdio.h>
int main(int argc, char** argv){
    float a,b;
    scanf("%f%f",&a,&b);
    if(a<b){
        printf("Input error!\n");
        return 0;
    }else if(a==b){
        printf("V=0.0");
    }
    printf("%.1f\n",pies*(trb(a)-trb(b)));
    return 0;
}
