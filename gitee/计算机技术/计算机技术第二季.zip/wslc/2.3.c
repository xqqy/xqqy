//Powered by Xqqy
#include<stdio.h>
int main(int argc, char** argv){
    int a;
    scanf("%d",&a);
    if((a%2)){
        printf("奇数\n");
    }else{
       printf("偶数\n");
    }
    return 0;
}
