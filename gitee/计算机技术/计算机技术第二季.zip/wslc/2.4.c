//Powered by Xqqy
#include<stdio.h>
int main(int argc, char** argv){
    int a;
    scanf("%d",&a);
    if(a<0){
        printf("固态\n");
    }else if(a<=100){
        printf("液态\n");
    }else{
        printf("气态\n");
    }
    return 0;
}
