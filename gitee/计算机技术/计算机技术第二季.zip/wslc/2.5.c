//Powered by Xqqy
#include<stdio.h>
int main(int argc, char** argv){
    double a,b;
    scanf("%lf,%lf",&a,&b);
    if(a>b){
        printf("%.2lf,%.2lf\n",a,b);
    }else{
        printf("%.2lf,%.2lf\n",b,a);
    }
    return 0;
}
