//Powered by Xqqy
#include<stdio.h>
int main(int argc, char** argv){
    double a;
    scanf("%lf",&a);
    if(a<0){
        printf("%.2lf\n",a+1);
    }else if(a<1){
        printf("11.00\n");
    }else{
        printf("%.2lf\n",a*a*a);
    }
    return 0;
}
