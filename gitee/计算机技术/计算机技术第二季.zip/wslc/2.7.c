//Powered by Xqqy
#include<stdio.h>
int main(int argc, char** argv){
    int a;
    scanf("%d",&a);
    if(!(a%400)){
        printf("闰年\n");
    }else if(!(a%100)){
        printf("不是闰年\n");
    }else if(!(a%4)){
        printf("闰年\n");
    }else{
        printf("不是闰年\n");
    }
    return 0;
}
