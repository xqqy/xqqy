//Powered by Xqqy
#include<stdio.h>
int main(int argc, char** argv){
    int a;
    scanf("%d",&a);
    if(a>5){
        printf("%d元\n",a*280);
    }else{
        printf("%d元\n",a*300);
    }
    return 0;
}
