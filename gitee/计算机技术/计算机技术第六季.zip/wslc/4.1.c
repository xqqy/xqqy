//Powered by xqqy
#include<stdio.h>
int main(){
    int i=0,max=0,min=0,t;
    scanf("%d",&t);
    max=t;
    min=t;
    for(i=0;i<9;i++){
        scanf("%d",&t);
        if(max<t){
            max=t;
        }
        if(min>t){
            min=t;
        }
    }
    printf("%d\n%d\n",max,min);
    return 0;
}