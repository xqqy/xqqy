//Powered by xqqy
#include<stdio.h>
int main(){
    char  a[60];
    int ans=0;
    scanf("%s",a);
    for (size_t i = 0; a[i]!=NULL; i++)
    {
      ans += a[i]-'0';
    }
    printf("%d\n",ans);
    return 0;
}
