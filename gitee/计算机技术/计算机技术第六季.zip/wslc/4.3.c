//Powered by xqqy
#include<stdio.h>
int main(){
    unsigned int a=100,ans=1;
    unsigned int y5,y10=0;//5元，10元，20元
    y5=a/5;
    int to20(int y10);
    if(y5==0){//没有方案
        printf("0种\n");
        return 0;
    }
    while(y5/2>0){//有两张5块可合成10块，方案+1
        y10++;
        y5-=2;
        ans++;
        if(y10/2>0){
            ans += to20(y10);
        }
    }
    printf("%d种\n",ans);
    return 0;
}

int to20(int y10){
    int y20=0,ans=0;
    while(y10/2>0){//有两张10块可合成10块，方案+1
        y20++;
        y10-=2;
        ans++;
    }
    return ans;
}