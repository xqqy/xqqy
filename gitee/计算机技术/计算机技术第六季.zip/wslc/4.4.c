//Powered by xqqy
#include<stdio.h>
int iszhi(int i);
int main(){
    int m;
    scanf("%d",&m);
    if(iszhi(m)){
        printf("素数\n");
    }else{
        printf("不是素数\n");
    }
    return 0;
}

int iszhi(int i){
    int t;
    for(t=2;t<i;t++){
            if(!(i%t)){//不是质数
                return 0;
            }
    }
    return 1;
}