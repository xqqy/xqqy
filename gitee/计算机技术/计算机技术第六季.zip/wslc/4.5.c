//Powered by xqqy
#include<stdio.h>
int main(){
    int m,n,chicken,rabbit;
    scanf("%d%d",&m,&n);
    for(chicken=0;chicken<m;chicken++){
        for(rabbit=0;rabbit<m;rabbit++){
            if(4*rabbit+2*chicken==n && rabbit+chicken==m){
                printf("鸡=%d,兔=%d\n",chicken,rabbit);
                return 0;
            }
        }
    }
    printf("无此结果\n");
    return 0;
}

