//Powered by xqqy
#include<stdio.h>
#define trb(x) (x)*(x)*(x)
int main(){
    for (int i = 100; i < 999; i++)
    {
        if(trb(i/100)+trb(i/10-(i/100)*10)+trb(i-(i/10)*10)==i){
            printf("%d\n",i);
        }
    }
    return 0;
}

