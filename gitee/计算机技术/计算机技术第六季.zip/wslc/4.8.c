//Powered by xqqy
#include<stdio.h>
int main(){
    double pi=1,to,a=3,mis=0.33333333,flag=-1;
    scanf("%lf",&to);
   while (mis>to)
   {
        pi +=flag*mis;
        flag *= -1;
        a += 2;
        mis=1/a;
   } 
   printf("%.5lf\n",pi*4);
   
    
    return 0;
}