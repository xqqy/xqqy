//Powered by xqqy
#include<stdio.h>
void go(char a);
int main(){
    for (int i = 0; i < 10; i++)
    {
        char a;
        scanf("%c",&a);
        go(a);
    }
    printf("\n");
    return 0;
}
void go(char a){  
    if('A'<=a && a<='Z'){  
        printf("大写,");  
    }else if('0'<=a && a<='9'){  
        printf("数字,");  
    }else if('a'<=a && a<='z'){  
         printf("小写,");  
    }else{  
        printf("其他,");  
    }  
}  