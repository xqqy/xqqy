#include<stdio.h>
#include<math.h>

int main(){
    int a,b,c,d,e=0,i;
    scanf("%d",&a);
    i=a;
    if (a==0)
    {
        printf("0\n");
    }
    else
    {
        while (a!=0) //计算整数位数
        {
            a=a/10;
            b++;
        }
        for (; b>=1 ; b--)
        {
            c=pow(10,b-1);
            d=i/c%10; //计算各位数的值
            e=e+d; //计算结果
        }
    }
    printf("%d\n",e);
    return 0;
}