//Powered by Xqqy

#include<stdio.h>
int main(int argc,char** argv){
    char a;
    int c,d;
    scanf("%d%c%d",&c,&a,&d);
    switch (a){
    case '+':
        printf("%d\n",c+d);
        break;
    case '-':
        printf("%d\n",c-d);
        break;
    case '*':
        printf("%d\n",c*d);
        break;
    case '/':
        if(d==0){
            printf("不能被0除\n");
            return -1;
        }
        printf("%d\n",c/d);
        break;
    default:
        printf("运算符有错\n");
        return -2;
        break;
    }
    return 0;
}