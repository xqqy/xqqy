//Powered by Xqqy

#include<stdio.h>
int main(int argc,char** argv){
    char a;
    scanf("%c",&a);
    switch (a){
    case 'A':
        printf("Your score:85~100\n");
        break;
    case 'B':
        printf("Your score:70~84\n");
        break;
    case 'C':
        printf("Your score:60~69\n");
        break;
    case 'D':
        printf("Your score:<60\n");
        break;
    default:
        printf("enter data error!\n");
        return -1;
        break;
    }
    return 0;
}