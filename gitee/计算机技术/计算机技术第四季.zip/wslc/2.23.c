//Powered by Xqqy
#include<stdio.h>

int isRun(int a);

int main(int argc, char** argv){
    int year,month;
    scanf("%d%d",&year,&month);
    if(month==2){//2月需要闰年判断
        if(isRun(year)){
            printf("29天\n");
        }else{
            printf("28天\n");
        }
        return 0;
    }

    if(month==1 || month==3 ||month==5 ||month==7 ||month==8 ||month==10 ||month==12){//1,3,5,7,8,10,12有31天
        printf("31天\n");
    }else{
        printf("30天\n");
    }
    return 0;
}

int isRun(int a){//闰年判断
if(!(a%400)){
        return 1;
    }else if(!(a%100)){
        return 0;
    }else if(!(a%4)){
        return 1;
    }else{
       return 0;
    }
}