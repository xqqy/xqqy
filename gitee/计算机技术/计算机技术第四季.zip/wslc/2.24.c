//Powered by Xqqy
#include<stdio.h>
int main(int argc,char** argv){
    int a;
    scanf("%d",&a);
    if(a<0 || a>100){
        printf("成绩错误\n");
        return -1;
    }
    switch (a/10){
    case 10:
    case 9:
        printf("A\n");
        break;
    case 8:
        printf("B\n");
        break;
    case 7:
        printf("C\n");
        break;
    case 6:
        printf("D\n");
        break;
    default:
        printf("E\n");
        break;
    }
    return 0;
}