//Powered by xqqy
#include <stdio.h>
#include<math.h>
#define ans1(a,b,c) (-(b)+sqrt((b)*(b)-4*(a)*(c)))/(2*(a))
#define ans2(a,b,c) (-(b)-sqrt((b)*(b)-4*(a)*(c)))/(2*(a))
//这些括号很重要！
int Nums(double a, double b, double c){
    double disc;
    disc=(int)(b*b)-(4*a*c);
    if(fabs(disc)<1e-60){//如果小的很，说明约等于0
        return 1;
    }else if(disc<0){//负数说明莫得根
        return -1;
    }else{
        return 2;
    }
}

int main(){
    double a,b,c;
    scanf("%lf%lf%lf",&a,&b,&c);
    if(Nums(a,b,c)==-1){
        printf("无实根\n");
    }else{
    printf("%.4lf\n%.4lf\n",ans1(a,b,c),ans2(a,b,c));
    }
    return 0;
}