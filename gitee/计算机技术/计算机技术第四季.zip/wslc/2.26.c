//Powered by xqqy
#include <stdio.h>
#include<math.h>
#define ans1(a,b,c) (-(b)+sqrt((b)*(b)-4*(a)*(c)))/2*(a)
#define ans2(a,b,c) (-(b)-sqrt((b)*(b)-4*(a)*(c)))/2*(a)

int Nums(double a, double b, double c){
    double disc;
    disc=(b*b)-(4*a*c);
    if(fabs(disc)<1e-10){//如果小的很，说明约等于0
        return 1;
    }else if(disc<0){//负数说明莫得根
        return -1;
    }else{
        return 2;
    }
}

int main(){
    double a,b,c;
    scanf("%lf,%lf,%lf",&a,&b,&c);
    switch (Nums(a,b,c))
    {
    case -1:
        printf("无实根\n");
        break;
    case 1:
        printf("有两个相等的实根\n");
        break;
    case 2:
        printf("有两个不等的实根\n");
        break;
    default:
        printf("MeowErr!");
        return -1;
        break;
    }
    return 0;
}