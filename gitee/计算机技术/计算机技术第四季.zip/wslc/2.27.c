    //Powered by Xqqy  
    #include<stdio.h>  
    int main(int argc, char** argv){  
        int a;  
        scanf("%d",&a);  
        if(a<1){  
            printf("%d\n",0);  
        }else if(a<10){  
            printf("%d\n",a);  
        }else{  
            printf("%d\n",a*a);  
        }  
        return 0;  
    }  