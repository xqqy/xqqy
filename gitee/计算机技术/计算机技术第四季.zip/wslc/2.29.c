    //Powered by Xqqy  
    #include<stdio.h>  
    int main(int argc, char** argv){  
        double a;  
        scanf("%lf",&a);  
        if(a<18){  
            printf("体重偏轻\n");  
        }else if(a<22.9){  
            printf("体重标准\n");  
        }else if(a<25){  
            printf("过重\n");  
        }else{  
            printf("肥胖\n");  
        }  
        return 0;  
    }  