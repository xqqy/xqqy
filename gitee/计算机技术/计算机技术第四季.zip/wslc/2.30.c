//Powered by Xqqy
#include<stdio.h>
int main(int argc,char** argv){
    int a,b,c,t;
    scanf("%d%d%d",&a,&b,&c);
    if(a>b){
        t=a;
        a=b;
        b=t;
    }
    if(c>b){
        t=c;
        c=b;
        b=t;
    }
    //b是最大的了
    if(a>c){
        printf("%d %d %d\n",b,a,c);
    }else{
        printf("%d %d %d\n",b,c,a);
    }
    return 0;
}


