//Powered by xqqy
#include<stdio.h>
int main(){
    char a;
    scanf("%c",&a);
    switch (a){
    case 'M':
        printf("买菜\n");
        break;
     case 'N':
        printf("午饭\n");
        break;
     case 'A':
        printf("午休\n");
        break;
     case 'E':
        printf("晚饭\n");
        break;
    default:
    printf("错误\n");
        break;
    }
    return 0;
}