//Powered by xqqy
#include<stdio.h>
int main(){
    char t;
    int m;
    scanf("%c%d",&t,&m);
    if(t=='V'){
        if(m<=500){
            printf("NO\n%.2f\n",m*0.85);
        }else if(m<=1000){
            printf("NO\n%.2f\n",m*0.8);
        }else{
            printf("YES\n%.2f\n",m*0.75);
        }
    }else{
        if(m<=500){
             printf("NO\n%.2f\n",m*0.9);
        }else{
            printf("YES\n%.2f\n",m*0.9);
        }
    }
}