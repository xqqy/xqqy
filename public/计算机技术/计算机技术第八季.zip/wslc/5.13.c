// Powered by xqqy
#include <stdio.h>
#define trc(x) ((x) * (x) * (x))
#define toint(x) ((x) - '0')
int main(int argc, char const *argv[])
{
    int num, total;
    scanf("%d", &num);
    if (num % 3 != 0)
    {
        printf("错误\n");
        return 0;
    }

    int ge;
    ge = num % 10;
    num /= 10;
    total = trc(ge) + trc(num % 10) + trc(num / 10);
    printf("%d,%d,%d,%d\n",ge,num%10,num/10,total);
    while (total != 153)
    {
        num = total;
        total = 0;
        while (num > 0)
        {
            total += trc(num % 10);
            printf("%d,", num % 10);
            num /= 10;
        }
        printf("%d\n", total);
    }
    return 0;
}
