//Powered by xqqy
//这段程序用于生成所有的5.16题目中的可能性
#include<stdio.h>
int updown(int a);
int main(int argc, char const *argv[])
{
    printf("{");
    int k;
    for (int i = 100; i < 999; i++)
    {
        k=i-updown(i);
        printf("%d,",k);
    }
    return 0;
}

int updown(int a){
    int sum=0;
    while (a>0)
    {
       sum += a%10;
       sum *= 10;
       a /= 10;
    }
    return sum/10;
}