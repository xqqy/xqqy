#include<stdio.h>
int main(int argc, char const *argv[])
{
    int a,sum=0;
    scanf("%d",&a);

    //这段代码由5.16.1.c/5.16.2.c/5.16.3.c生成
if(99<a){sum+=90;}
if(-99<a){sum+=80;}
if(-198<a){sum+=70;}
if(-297<a){sum+=60;}
if(-396<a){sum+=50;}
if(-495<a){sum+=40;}
if(-594<a){sum+=30;}
if(-693<a){sum+=20;}
if(-792<a){sum+=10;}
if(198<a){sum+=80;}
if(297<a){sum+=70;}
if(396<a){sum+=60;}
if(495<a){sum+=50;}
if(594<a){sum+=40;}
if(693<a){sum+=30;}
if(792<a){sum+=20;}
if(891<a){sum+=10;}
if(0<a){sum+=89;}

printf("%d\n",sum-1);
    
    return 0;
}
