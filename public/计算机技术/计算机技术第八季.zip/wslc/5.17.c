//Powered by xqqy
#include<stdio.h>
int main(int argc, char const *argv[])
{
    char numbers[200];
    scanf("%s",numbers);
    unsigned int size=0;
    while(numbers[size]!='\0'){
        size++;
    }
    if(size==1){
        printf("是\n");
        return 0;
    }
    size--;
    for (int i = 0; i < size/2; i++)
    {
        if(numbers[i]!=numbers[size-i]){
            printf("不是\n");
            return 0;
        }
    }
    printf("是\n");
    return 0;
}
