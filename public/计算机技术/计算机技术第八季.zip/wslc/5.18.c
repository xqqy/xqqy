// Powered by xqqy
#include <stdio.h>
int main(int argc, char const *argv[]) {
  int l,a,b;
  scanf("%d%d%d",&l,&a,&b);
  struct all
  {
      int a;
      int b;
      int lost;
  } meow;
  meow.lost=l;
  meow.a=0;
  meow.b=0;
  for (unsigned int i = 0; i < l/a; i++)
  {
      for (unsigned int t = 0; t < l/b; t++)
      {
          if(l-i*a-t*b<meow.lost){
              meow.lost=l-i*a-t*b;
              meow.a=i;
              meow.b=t;
          }
      }
  }
  printf("%d,%d,%d\n",meow.a,meow.b,meow.lost);
  return 0;
}
