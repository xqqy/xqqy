// Powered by xqqy
#include <stdio.h>
int main(int argc, char const *argv[]) {
  char a;
  scanf("%c", &a);
  if ('a' <= a && a <= 'z') {
    for (char i = a+1; i <= 'z'; i++) {
      printf("%c", i);
    }
    for (char i = 'a'; i <= a; i++) {
       printf("%c", i);
    }
  } else if ('A' <= a && a <= 'Z') {
    for (char i = a+1; i <= 'Z'; i++) {
      printf("%c", i);
    }
    for (char i = 'A'; i <= a; i++) {
      printf("%c", i);
    }
  } else {
    return -1;
  }
  printf("\n");
  return 0;
}
