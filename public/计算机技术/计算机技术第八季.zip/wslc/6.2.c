// Powered by xqqy
#include <stdio.h>
int main(int argc, char **argv) {
  float numbers[10],sum=0;
  for (int i = 0; i < 10; i++)
  {
      scanf("%f",&numbers[i]);
      sum +=numbers[i];
  }
  sum/=10;
  printf("均值=%.1f\n",sum);
  for (int i = 0; i <= 9; i++)
  {
    if(numbers[i]<sum)
        printf("%.1f,",numbers[i]);
  }
  printf("\n");
  return 0;
}