// Powered by xqqy
#include <stdio.h>
int main(int argc, char const *argv[]) {
  char a;
  scanf("%c", &a);
  if ('a' <= a && a <= 'z') {
    printf("小写\n");
  } else if ('A' <= a && a <= 'Z') {
    printf("大写\n");
  }else{
      return -1;
  }
  return 0;
}
