// Powered by xqqy
#include <stdio.h>
int main(int argc, char const *argv[]) {
    double a=1,b;
  for (int i = 0; i < 8; i++)
  {
     scanf("%lf",&b);
     a *=b;
  }
  printf("%.2lf\n",a);
  return 0;
}
