// Powered by xqqy
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int a=-2147483648,b;
    for (int i = 0; i < 10; i++)
    {
        scanf("%d",&b);
        if(b>a)
            a=b;
    }
    printf("%d\n",a);
    
    return 0;
}
