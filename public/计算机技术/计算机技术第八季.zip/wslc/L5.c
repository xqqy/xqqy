// Powered by xqqy
#include <stdio.h>

int main(int argc, char const *argv[])
{
    int a;
    scanf("%d",&a);
    if(a%2)
    {
        printf("%d\n",(1+a)/2*(a/2+1));
    }else
    {
        a--;
        printf("%d\n",(1+a)/2*(a/2+1));
    }
    
    return 0;
}
