//Powered by xqqy
#include<stdio.h>
int main(int argc, char const *argv[])
{
    double a,b,c;
    scanf("%lf,%lf,%lf",&a,&b,&c);
    printf("%.2lf\n",(a+b)/c/2);
    return 0;
}
