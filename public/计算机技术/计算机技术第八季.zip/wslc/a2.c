//Powered by xqqy
#include<stdio.h>
int main(int argc, char const *argv[])
{
    float number;
    scanf("%f",&number);
    if(number<1 || number>4){
        printf("绩点非法\n");
        return 0;
    }
    if(number==4){
        printf("90分以上\n");
        return 0;
    }
    printf("%.1f=%.0f分\n",number,50+10*number);
    return 0;
}
