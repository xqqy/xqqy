//Powered by xqqy
#include<stdio.h>
int main(int argc, char const *argv[])
{
    int m,n;
    scanf("%d%d",&m,&n);
    for (int i = 0; i <= m; i++)//i=>蜘蛛
    {
        /* code */
        if(i*8-(m-i)*3==n){
            printf("买A种票的人数=%d\n",i);
            return 0;
        }
    }
    printf("无解决方案\n");
    return 0;
}
