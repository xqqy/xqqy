//Powered by xqqy
#include<stdio.h>
int main(int argc, char const *argv[])
{
    char input[10086];
    scanf("%s",input);
    for (int i = 0; input[i]; i++)
    {
        /* code */
        printf("%c",input[i]-32);
    }
    printf("\n");
    return 0;
}
