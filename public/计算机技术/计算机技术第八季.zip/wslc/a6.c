// Powered by xqqy
#include <stdio.h>

int tru(int a, int b);

int main(int argc, char const *argv[]) {
  int a, b, n;
  scanf("%d%d%d", &a, &b, &n);
  int sum = a;
  printf("%d,", a);

  //如果只有第一个
  if (n < 2) {
    printf("\nsum=%d\n", sum);
  }

  printf("%d%d,", a, b);
  sum += a * 10 + b;

  //开始输出第三项之后的
  int t;
  for (int i = 1; i < n-1; i++) {
    printf("%d", a);
    for (t = 0; t < i; t++) {
      printf("%d", b);
    }
    printf("%d,", a);
    sum += a * tru(10, t + 1) + a;//把两个头先加上
    for (; t > 0; t--) {
      sum += b * tru(10, t);//把中间的也加上
    }
  }
  printf("\nsum=%d\n", sum);
  return 0;
}

int tru(int a, int b) {//幕函数
    int ans=a;
    b--;
  for (int i = 0; i < b; i++) {
    ans *= a;
  }
  return ans;
}