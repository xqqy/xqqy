//Powered by xqqy

#include<stdio.h>
int iszhi(int i)  
{  
    int t;  
    for (t = 2; t < i; t++)  
    {  
        if (!(i % t))
        { //不是质数  
            return 0;  
        }  
    }  
    return 1;  
} 

int main(int argc, char const *argv[])
{
    int a;
    scanf("%d",&a);
    if(iszhi(a)){
        printf("是\n");
    }else{
         printf("不是\n");
    }
    return 0;
}
