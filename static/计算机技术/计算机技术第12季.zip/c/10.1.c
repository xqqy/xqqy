  int fun(int a){
      int sum=0;
      while (a>0)
      {
          sum+=a;
          a--;
      }
      return sum;
  }
  
    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
     
    #include <stdio.h>  
    int main()  
    {  
        int s,n;  
        scanf("%d",&n);  
        s=fun(n);//调用fun函数累计1-n的和  
        printf("%d\n",s);  
    return 0;  
    }  
      
    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */  