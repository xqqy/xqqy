int fun(const int input){
    int ans=0;
    for (int i = input-1; i >0; i--)
    {
        if(input%i==0)
            ans+=i;
    }
    return ans;
}

    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
     
    #include<stdio.h>  
    int main()  
    {  
      int i,n,s;  
      scanf("%d",&n);  
      for(i=2;i<=n;i++)  
      {     
          s=fun(i);//通过函数fun调用来计算某数i的真因子之和  
          if(s==i)//符合完全数的条件  
             printf("%d\n",s);  
      }  
      return 0;  
    }  
      
    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */ 