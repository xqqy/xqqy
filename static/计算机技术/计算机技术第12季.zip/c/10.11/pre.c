#include<stdio.h>
int main(int argc, char const *argv[])
{
    printf("{1,2,");
    unsigned long long  a=1,b=2,t,num=0;
    while (num<89)
    {
        t=a+b;
        printf("%lld,",t);
        a=b;
        b=t;
        num++;
    }
    return 0;
}
