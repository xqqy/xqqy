#include <stdio.h>
void showtri(int n) {
    n = (n * 2 - 1);
    int first=n/2;
    for (int i = 1; i <= first; i++) {
        for (int f = 0; f < first - i+1; f++) {
            printf(" ");
        }
        for (int t = 0; t < i * 2 - 1; t++) {
            printf("*");
        }
        printf("\n");
    }

    //中间那行
    for (int t = 0; t < n; t++) {
        printf("*");
    }
    printf("\n");
}
void showinverttri(int n) {
    n = (n * 2 - 1) / 2;
    for (int i = n; i >= 1; i--) {
        for (int f = 0; f < n - i+1; f++) {
            printf(" ");
        }
        for (int t = 0; t < i * 2 - 1; t++) {
            printf("*");
        }
        printf("\n");
    }
    return;
}
/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

int main() {
    int n;
    scanf("%d", &n);
    showtri(n);        //输出正三角形
    showinverttri(n);  //输出倒三角形
    return 0;
}

/* PRESET CODE END - NEVER TOUCH CODE ABOVE */