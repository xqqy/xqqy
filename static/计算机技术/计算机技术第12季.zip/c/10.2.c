    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
     
    #include <stdio.h>  
    int fun(int x)//定义求阶乘的函数  
    {  
        int jc=1,i;  
        for(i=1;i<=x;i++)  
            jc=jc*i;      
        return jc;  
    }  
    int main()  
    {  
        int m,n;  
        scanf("%d%d",&m,&n);//输入实参m和n  
      
    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */  
    printf("sum=%d\n",fun(m)+fun(n));
    }