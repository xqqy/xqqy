    float fun(const float x){
        if(x<0)
            return x+1;
        else if(x<1)
            return 11.0;
        else
            return x*x*x;
    }

    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
     
    #include  <stdio.h>  
    int main()        
    {  
        float x,y;  
        scanf("%f",&x);  
        y=fun(x);  
        printf("%.2f\n",y);  
        return 0;     
    }  
      
    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */  