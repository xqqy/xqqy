/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

int fun(int m)  //函数定义
{
    int i;
    for (i = 2; i < m; i++)
        if (m % i == 0)
            break;
    if (i == m)
        return 1;
    else
        return 0;
}

/* PRESET CODE END - NEVER TOUCH CODE ABOVE */
#include <stdio.h>
int main(int argc, char const* argv[]) {
    int a;
    scanf("%d",&a);
    if(fun(a))
        printf("素数\n");
    else
        printf("不是素数\n");
    return 0;
}
