int isrun(int a);
int fun(int year, int month, int day) {
    int norun[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int run[] = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int* touse;

    // scanf("%d%d%d", &year, &month, &day);
    if (month > 12 || month < 0 || year < 0) {
        printf("错误！数据不合法");
        return -1;
    }
    if (isrun(year))
        touse = run;
    else
        touse = norun;
    month--;
    int ans = 0;
    for (int i = 0; i < month; i++) {
        ans += touse[i];
    }
    return ans + day;
    return 0;
}

int isrun(int a) {
    if (!(a % 400)) {
        return 1;
    } else if (!(a % 100)) {
        return 0;
    } else if (!(a % 4)) {
        return 1;
    } else {
        return 0;
    }
}
/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

#include <stdio.h>
int main() {
    int fun(int y, int m, int d);  //函数声明，因为定义在调用之后
    int y, m, d;
    scanf("%d%d%d", &y, &m, &d);
    printf("第%d天\n", fun(y, m, d));  //函数调用
    return 0;
}

/* PRESET CODE END - NEVER TOUCH CODE ABOVE */