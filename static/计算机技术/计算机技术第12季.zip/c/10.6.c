    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
      
    int fun(int n)//函数定义  
    {  
      int a[30]={1,1},i;  
      for(i=2;i<n;i++)/*构建数列第3项以及其后的项*/  
          a[i]=a[i-1]+a[i-2];  
      return a[n-1];//返回第n项  
    }  
      
    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */  
    #include<stdio.h>
    int main(int argc, char const *argv[])
    {
        int input;
        scanf("%d",&input);
        printf("%d\n",fun(input));
        return 0;
    }
    