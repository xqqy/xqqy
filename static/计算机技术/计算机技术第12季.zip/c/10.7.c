/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

#include <stdio.h>
void fun(int x)  //定义无返回值函数
{
    while (x > 0) {
        printf("%d", x % 10);
        x = x / 10;
    }
    printf("\n");
}

/* PRESET CODE END - NEVER TOUCH CODE ABOVE */
#include <stdio.h>
int main(int argc, char const* argv[]) {
    int input;
    scanf("%d", &input);
    fun(input);
    return 0;
}
