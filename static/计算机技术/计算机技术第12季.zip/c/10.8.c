/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

#include <stdio.h>
int main() {
    int fun(int m);  //函数声明,因为函数定义在调用之后
    int n;
    scanf("%d", &n);
    printf("%d\n", fun(n));  //函数调用,有返回值
    return 0;
}

/* PRESET CODE END - NEVER TOUCH CODE ABOVE */
int fun(int x)  //定义无返回值函数
{
    int a = 0;
    while (x > 0) {
        a *= 10;
        a += x % 10;
        x = x / 10;
    }
    return a;
}
