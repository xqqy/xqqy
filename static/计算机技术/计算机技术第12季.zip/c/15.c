#include<stdio.h>

int islucky(int input);
int main(int argc, char const *argv[])
{
    int max;
    scanf("%d",&max);
    for (int i = 7; i <= max; i++)
    {
        if(islucky(i) && max%i==0){
            printf("Y\n");
            return 0;
        }
    }
    
    printf("N\n");
    return 0;
}


int islucky(int input)
{
    while (input>0)
    {
        if(input%10!=7 && input%10!=4)
            return 0;
        input /= 10;
    }
    return 1;
}
