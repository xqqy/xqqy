#include <stdio.h>  
float fun(float x)
{
	float a,b,c,i,s=0;
	a=1;
	b=1;
	for(i=1;i<=x;i++)
	{
		c=a+b;
		s=s+(c/b);
		a=b;
		b=c;
	}
	return s;
} 
int main()  
{  
int n;  
scanf("%d",&n);  
printf("%.5f\n",fun(n));//调用fun函数计算多项式之和  
return 0;  
}
