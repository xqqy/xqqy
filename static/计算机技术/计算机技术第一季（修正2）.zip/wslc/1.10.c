//Powered by Xqqy
#include<stdio.h>
int main(int argc, char** argv){
    float cm;
    scanf("%f",&cm);
    printf("%0.2f\n%0.2f\n",cm/2.54,cm/30.48);
}
