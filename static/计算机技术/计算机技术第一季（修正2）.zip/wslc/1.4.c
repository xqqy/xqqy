//Powered by Xqqy
#include<stdio.h>
#define pie 3.1415926
int main(int argc, char** argv){
    double r;
    scanf("%lf",&r);
    printf("%lf\n",pie*r*r);
}