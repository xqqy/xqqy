//Powered by Xqqy
#include<stdio.h>
int main(int argc, char** argv){
    float l,w,h;
    scanf("%f,%f,%f",&l,&w,&h);
    printf("%0.2f\n",l*w*h);
}