//Powered by Xqqy
#include<stdio.h>
int main(int argc, char** argv){
    const float a = 0.5555555555;
    float f;
    scanf("%f",&f);
    printf("%0.2f\n",a*(f-32));
}