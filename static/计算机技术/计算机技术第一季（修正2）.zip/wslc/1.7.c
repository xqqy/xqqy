//Powered by Xqqy
#include<stdio.h>
int main(int argc, char** argv){
    float a,b;
    scanf("%f%f",&a,&b);
    printf("总评=%5.2f\n",a*0.3+b*0.7);
}