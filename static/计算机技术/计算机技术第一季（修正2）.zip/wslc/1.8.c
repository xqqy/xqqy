//Powered by Xqqy
#include<stdio.h>
#define pie2 6.2831852
int main(int argc, char** argv){
    float r,h;
    scanf("%f%f",&r,&h);
    printf("%5.3f\n",pie2*r*(h+r));
}
