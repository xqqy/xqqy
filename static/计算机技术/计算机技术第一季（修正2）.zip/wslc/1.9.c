//Powered by Xqqy
#include<stdio.h>
int main(int argc, char** argv){
    float r;
    scanf("%f",&r);
    printf("%5.1f元\n",219.8*r);
}