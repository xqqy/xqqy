//Powered by Xqqy
#include <stdio.h>
int main(int argc, char** argv)
{
    printf(" 静夜思\n床前明月光，\n疑是地上霜。\n举头望明月，\n低头思故乡。\n");
    return 0;
}