//Powered by Xqqy
#include <stdio.h>
int main(int argc, char** argv)
{
    int a;
    scanf("%d",&a);
    printf("%d\n",a);
    return 0;
}