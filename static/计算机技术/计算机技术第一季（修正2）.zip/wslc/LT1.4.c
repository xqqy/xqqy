//Powered by Xqqy
#include <stdio.h>
int main(int argc, char** argv)
{
    float a,b,c;
    scanf("%f%f",&a,&b);
    printf("%0.1f\n",a-b);
    return 0;
}