//Powered by Xqqy
#include <stdio.h>
int main(int argc, char** argv)
{
    float a,b;
    scanf("%f%f",&a,&b);
    printf("%0.2f\n",a/b);
    return 0;
}