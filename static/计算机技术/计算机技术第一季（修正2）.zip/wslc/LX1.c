//Powered by Xqqy
#include<stdio.h>
int main(int argc, char** argv){//这是进入函数，其中argc是在程序后面附加的语句个数，argv是一个数组，表示了后面附加的都是什么
    int a,b;//声明变量，C语言对于变量的声明是有分类的。可以看变量类型.md来了解；Windows10用户可以下载这个应用来更好的看https://www.microsoft.com/store/productId/9N3JDZHPDJDM
    scanf("%d%d",&a,&b);
    printf("%d\n",a%b);
}

//附加命令：比如对一个程序：a.exe；命令行窗口里面也可以这么调用：a.exe huaji ijauh；这时argc就是2，argv则是一个char*类型的数组，长度是2，第一项是huaji，第二项是ijaua
