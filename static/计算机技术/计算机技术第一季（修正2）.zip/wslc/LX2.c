//Powered by Xqqy
#include<stdio.h>
int main(int argc, char** argv){
    int a,b;
    scanf("%d%d",&a,&b);
    printf("%d %d\n",b,a);
}
