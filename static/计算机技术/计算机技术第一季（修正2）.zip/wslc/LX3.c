//Powered by Xqqy
#include <stdio.h>
int main()
{
    char a[2];
    scanf("%c%c",&a[0],&a[1]);
    printf("%c%c%c\n",a[0],',',a[1]);
}