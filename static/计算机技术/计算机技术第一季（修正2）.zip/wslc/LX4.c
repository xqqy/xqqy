//Powered by Xqqy
#include <stdio.h>
int main()
{
    char a;
    scanf("%c",&a);
    printf("%c\n",a+32);
}