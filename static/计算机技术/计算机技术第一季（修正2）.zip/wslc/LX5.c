//Powered by Xqqy
#include<stdio.h>
#define chartonumber(x) (x-'0')
int main(int argc, char** argv){
    char input[4];
    int a;
    scanf("%c%c%c%c",&input[0],&input[1],&input[2],&input[3]);
    a= chartonumber(input[0])+chartonumber(input[1])+chartonumber(input[2])+chartonumber(input[3]);
    printf("%c%c%c%c,%c%c%c%c,%d\n",input[3],input[2],input[1],input[0],input[2],input[3],input[0],input[1],a);
}
