//Powered by Xqqy
#include<stdio.h>
int main(int argc, char** argv){
    float l,w;
    scanf("%f%f",&l,&w);
    printf("%5.3f\n",l*w);
}