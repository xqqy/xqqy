#include <stdio.h>
int main(){
    float i,x,sum;
    scanf("%f%f",&i,&x);
    sum=i/x;
    printf("%.4f\n",sum);
    return 0;
} 
#ifdef
#endif