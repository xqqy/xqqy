//Powered by Xqqy

#include<stdio.h>
int main(int argc, char** argv){
    int a,b,c,d;
    scanf("%d%d%d%d",&a,&b,&c,&d);
    if(a==b && b==c && c==d){
        printf("是\n");
    }else{
        printf("不是\n");
    }
    return 0;
}