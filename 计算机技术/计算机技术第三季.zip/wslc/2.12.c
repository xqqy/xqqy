//Powered by Xqqy

#include<stdio.h>
int main(int argc, char** argv){
    int a,b,c;
    scanf("%d%d%d",&a,&b,&c);
    if(a+b>c && b+c>a && a+c>b &&a-b<c && b-a<c && a-c<b && c-a<b && b-c<a && c-b<a){
        printf("是\n");
    }else{
        printf("不是\n");
    }
    return 0;
}