//Powered by Xqqy
#include<stdio.h>
#include<math.h>
int isTrc(float a ,float b ,float c){
    
    if(a+b>c && b+c>a && a+c>b &&a-b<c && b-a<c && a-c<b && c-a<b && b-c<a && c-b<a){
        return 1;
    }else{
        return 0;
    }
}

int main(int argc,char** argv){
    float a,b,c;
    scanf("%f%f%f",&a,&b,&c);
    if(!isTrc(a,b,c)){
        printf("不能构成三角形\n");
    }else{
        float p=(a+b+c)/2;
        printf("面积为%.2f\n",sqrt(p*(p-a)*(p-b)*(p-c)));
    }
    return 0;
}