//Powered by Xqqy

#include<stdio.h>
int main(int argc, char** argv){
    int a,b,c;
    scanf("%d%d%d%d",&a,&b,&c);
    if(a==b && b==c){
        printf("是等边三角形\n");
    }else{
        printf("不是等边三角形\n");
    }
    return 0;
}