#include<stdio.h>
#define toint(x) ((x)-'0')
int main(int argc, char** argv){
    char a,b,c;
    scanf("%c%c%c",&a,&b,&c);
    if(a=='3' || b=='3' || c=='3' || !((toint(a)+toint(b)+toint(c))%3)){
        printf("%c%c%c\n",a,b,c);
    }else{
        printf("不含3\n");
    }
    return 0;
}