#include<stdio.h>
int main(int argc,char** argv){
    float a,b,c,averge;
    scanf("%f%f%f",&a,&b,&c);
    averge=(a+b+c)/3;
    if(a>averge){
        printf("%.1f\n",a);
    }
     if(b>averge){
        printf("%.1f\n",b);
    }
     if(c>averge){
        printf("%.1f\n",c);
    }
    return 0;
}