//Powered by Xqqy
#include<stdio.h>


int main(int argc, char** argv){
    float a,b,c;
    scanf("%f%f%f",&a,&b,&c);
    if(a>b){
        if(b>c){
            printf("%.2f\n",c);
        }else{
            printf("%.2f\n",b);
        }
    }else{
        if(a>c){
            printf("%.2f\n",c);
        }else{
            printf("%.2f\n",a);
        }
    }
    return 0;
}
