//Powered by Xqqy
#include<stdio.h>


int main(int argc, char** argv){
    char a;
    scanf("%c",&a);
    if('A'<=a && a<='Z'){
        printf("%c",a+32);
    }else{
        printf("%c",a);
    }
    return 0;
}
