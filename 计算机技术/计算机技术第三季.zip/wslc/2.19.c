//Powered by Xqqy
#include<stdio.h>


int main(int argc, char** argv){
    char a;
    int money;
    scanf("%c%d",&a,&money);
    if(a=='N'){
        printf("登陆=0分\n购物=0分\n");
    }else{
        printf("登陆=5分\n");
        if(money>=300){
            money-=300;
            printf("购物=%d分\n",(money/100*10)+30);
        }else{
            printf("购物=0分\n");
        }
    }
    return 0;
}
