//Powered by Xqqy
#include<stdio.h>


int main(int argc, char** argv){
    char a;
    scanf("%c",&a);
    if('A'<=a && a<='Z'){
        printf("大写字母\n");
    }else if('0'<=a && a<='9'){
        printf("数字字符\n");
    }else if('a'<=a && a<='z'){
         printf("小写字母\n");
    }else{
        printf("其他字符\n");
    }
    return 0;
}
