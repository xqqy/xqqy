    //Powered by Xqqy  
    #include<stdio.h>  
      
    int main(int argc, char** argv){  
        int a;  
        scanf("%d",&a);  
        if(a>0){  
            printf("%d是正数\n",a);  
        }else if(a<0){  
            printf("%d是负数\n",a);  
        }else{  
            printf("非正非负\n");  
        }  
        return 0;  
    }  