// powered by xqqy
#include <stdio.h>
#include <stdlib.h>

// MeowArray lib start;Powered by xqqy!
typedef struct
    MeowArray  //双向链表技术！！!(isfirst和isend更方便喵看它是不是越界！)
{
    struct MeowArray* forward;
    struct MeowArray* back;
    int data;
    int isfirst;
    int isend;
} MeowArray;

//默认返回第一个节点
MeowArray* MeowArrayNew(const int first)  //创建第一个MeowArray节点
{
    MeowArray* node;                               //当前节点
    node = (MeowArray*)malloc(sizeof(MeowArray));  //输入第一个节点
    node->isfirst = 1;
    node->isend = 1;
    node->data = first;

    return node;
}

MeowArray* MeowArrayAppend(MeowArray *first,
                           const int what) {  //在末尾插入新变量
    MeowArray* node;
    node=first;
    while (!node->isend)  //获取末尾节点
    {
        node = node->back;
    }

    //末尾节点
    MeowArray* forward;
    forward = node;                                //前一个结点
    node = (MeowArray*)malloc(sizeof(MeowArray));  // new一个新节点
    node->data = what;                             //输入数据
    node->forward = forward;                       //更改指针
    forward->back = node;
    node->isfirst = 0;  //更改flag
    node->isend = 1;
    forward->isend = 0;

    return first;
}

int MeowArrayIndexOf(MeowArray* node,const int what) {  //获取变量第一次出现在数组内的位置，没有就返回-1
    while (!node->isfirst) {  //确保为开始节点
        node = node->forward;
    }

    if (node->data == what)//只有一个长度的第一个节点是
        return 0;


    unsigned long long i = 0;
    for (; !node->isend; i++) {
        if (node->data == what)
            return i;
        node = node->back;
    }
    if (node->data == what)//最后一个节点是
        return i;
        
    else
        return -1;
}

MeowArray* MeowArrayDel(MeowArray* node, const int pos) {
    while (!node->isfirst) {  //确保为开始节点
        node = node->forward;
    }

    for (unsigned long long i = 0; i < pos; i++) {  //获取需要被删除的节点
        node = node->back;
    }

    if(node->isend && node->isfirst){//只有一个长度的数组
        free(node);
        return NULL;
    }
    else if (!node->isfirst && !node->isend) {  //中间的就把他们连起来
        MeowArray *forward, *back;
        forward = node->forward;
        back = node->back;
        free(node);  //你自由啦（x
        //更改指针
        forward->back = back;
        back->forward = forward;
        node=forward;
    } else if (node->isend) {
        node = node->forward;
        free(node->back);
        node->isend = 1;  //所有isend的时候，back指针用了就是错……

    } else {
        node = node->back;
        free(node->forward);
        node->isfirst = 1;  //所有isfirst的时候，forward指针用了就是错……
    }

    //返回第一个结点
    while (!node->isfirst) {
        node = node->forward;
    }
    return node;
}

int MeowArrayAt(MeowArray* node,int where){//获取第几个位置的值
    while (!node->isfirst) {  //确保为开始节点
        node = node->forward;
    }
    for (int i = 0; i < where; i++)
    {//挪动指针
        if(node->isend)//请注意，如果这个值不在数组里面，就直接以-100错误代码退出程序了
            exit(-100);
        else
            node=node->back;
    }
    return node->data;
    
}
int MeowArrayLength(MeowArray* node){
    while (!node->isfirst) {  //确保为开始节点
        node = node->forward;
    }
    unsigned long long i=0;
    while (!node->isend) {  //确保为开始节点
        node = node->back;
        i++;
    }
    return ++i;
}
// MeowArray lib end;Powered by xqqy!

int main(){
    MeowArray *list=MeowArrayNew(1);
    MeowArrayAppend(list,2);
    MeowArrayAppend(list,3);
    MeowArrayAppend(list,4);
    MeowArrayAppend(list,6);
    MeowArrayAppend(list,9);
    MeowArrayAppend(list,12);
    MeowArrayAppend(list,23);
    MeowArrayAppend(list,45);
    int input;
    scanf("%d",&input);
    int index=MeowArrayIndexOf(list,input);
    if(index>-1)
        list=MeowArrayDel(list,index);
    else{
        printf("无此数\n");
        return 0;
    }
    if(list!=NULL){
       /* while (!list->isend)
        {
            printf("%d,",list->data);
            list=list->back;
        }
        printf("%d,\n",list->data);*/
        for (int i = 0; i < MeowArrayLength(list); i++)
        {
            printf("%d,",MeowArrayAt(list,i));
        }
        printf("\n");
    }else
        return -1;
    
    return 0;
}