#include<stdio.h>
#include<string.h>
int main(int argc, char const *argv[])
{
    char gay[11];
    fgets(gay,11,stdin);
    int num=strlen(gay)-1;
    gay[num]='\0';
    printf("%s,你好\n",gay);
    return 0;
}
