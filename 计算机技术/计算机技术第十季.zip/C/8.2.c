#include<stdio.h>
#include<string.h>
int main(int argc, char const *argv[])
{
    char str[11];
    fgets(str,11,stdin);
    for (int i = strlen(str)-2; i >=0 ; i--)
    {
        printf("%c",str[i]);
    }
    printf("\n");
    return 0;
}