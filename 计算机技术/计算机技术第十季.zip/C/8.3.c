/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

#include <stdio.h>
int main()
{
    char c[100];
    gets(c); //接受从键盘输入的一个字符串（可带空格）

    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */

    for (int i = 0; c[i]!='\0'; i++)
    {
        if(c[i]>='A' && c[i]<='Z')
            c[i]+=32;
    }
    

    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

    printf("%s\n", c); //整体输出转换后的字符串
    return 0;
}

/* PRESET CODE END - NEVER TOUCH CODE ABOVE */