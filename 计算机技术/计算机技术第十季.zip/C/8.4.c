// powered by xqqy
#include <regex.h>
#include <stdio.h>
#include <string.h>
int main(int argc, char const* argv[]) {
    char str[101];
    int abc = 0, num = 0, other = 0;
    fgets(str, 101, stdin);
    regex_t nonspace;
    regcomp(&nonspace, "[a-zA-Z]",REG_EXTENDED);  //非空白字符
    regex_t numbers;
    regcomp(&numbers, "[0-9]",REG_EXTENDED);  //数字
    regmatch_t ans[1];
    for (int i = 0; i < strlen(str); i++) {
        char text[1];
        text[0] = str[i];
        if (regexec(&numbers, text, 1, ans, REG_NOTBOL) !=
            REG_NOMATCH) {  //数字
            num++;
        } else if (regexec(&nonspace, text, 1, ans, REG_NOTBOL) !=
                   REG_NOMATCH) {
            abc++;
        } else {
            other++;
        }
    }

    printf("字母数=%d,数字数=%d,其他字符数=%d\n",abc,num,--other);
    regfree(&nonspace);
    regfree(&numbers);
    return 0;
}
