//powered by xqqy
#include <stdio.h>
#include <string.h>
int main() {
    char a[101];
    int num, i;
    fgets(a, 101, stdin);
    for (i = 0; i < strlen(a); i++) {
        if ((a[i] >= 'A' && a[i] <= 'V') || (a[i] >= 'a' && a[i] <= 'v')) {
            a[i] = a[i] + 4;
        }else if ((a[i] >= 'W' && a[i] <= 'Z') || (a[i] >= 'w' && a[i] <= 'z')) {
            a[i] -= 22;
        }
    }
    printf("%s", a);
    return 0;
}