//powered by xqqy
#include<stdio.h>
#include<string.h>
#include<regex.h>
int main(int argc, char const *argv[])
{
    char str[101];
    fgets(str,101,stdin);
    regex_t reg;
    regcomp(&reg,".*,",REG_EXTENDED);
    regmatch_t ans[1];
    
    if (regexec(&reg,str,1,ans,REG_NOTBOL)==REG_NOMATCH)
    {
        printf("no");
    }else{
        for (int i = 0; i < ans[0].rm_eo-1; i++)
        {
            printf("%c",str[i]);
        }
        printf("\n");
        for (int i = ans[0].rm_eo; i < strlen(str); i++)
        {
            printf("%c",str[i]);
        }        
    }
    regfree(&reg);
    return 0;
}
