#include<stdio.h>
#include<string.h>
int main(int argc, char const *argv[])
{
    char str[101];
    fgets(str,101,stdin);
    int isletter=0;//=1 means a letter appear
    int ans=0;
    for (int i = 0; i < strlen(str)-1; i++)
    {
        if(str[i]!=' ' && isletter==0){
            ans++;
            isletter=1;
        }else if(str[i]==' '){
            isletter=0;
        }
    }
    printf("%d words\n",ans);
    return 0;
}
