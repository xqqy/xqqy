#include<stdio.h>
#include<string.h>
int main(int argc, char const *argv[])
{
    int ans=0;
    while (1)
    {
        int get= getchar();
        if(get!=10)
            ans += get-'A'+1;
        else
            break;
    }
    printf("%d\n",ans);
    return 0;
}
