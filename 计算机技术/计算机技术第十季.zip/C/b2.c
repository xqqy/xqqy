//powered by xqqy
#include <stdio.h>
int main()
{
    int num,maxs=-100861086,temp,max=0;
    scanf("%d", &num);
    for (int i = 0; i < num; i++)
    {
        scanf("%d",&temp);
        if(temp>maxs){
            maxs=temp;
            max=i;
        }
    }
    int a[max+1];
    a[max]=maxs;

    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

    printf("%d位于第%d\n", a[max], max + 1);
    return 0;
}

/* PRESET CODE END - NEVER TOUCH CODE ABOVE */