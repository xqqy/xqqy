#include <stdio.h>
int main()
{
    float a, b;
    scanf("%f", &a);
    if (a < 0 || a > 100)
        printf("成绩非法\n");
    else
    {
        if (a < 60)
        {
            printf("%.0f分=0.0\n", a);
        }
        else
        {
            if (a > 90)
                b = 4;
            else
                b = a / 10 - 5;
            printf("%.0f分=%.1f\n", a, b);
        }
    }
    return 0;
}