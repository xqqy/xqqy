//powered by xqqy
#include <stdio.h>
int main()
{
    int num,maxs=100861086,temp,min=0;
    scanf("%d", &num);
    for (int i = 0; i < num; i++)
    {
        scanf("%d",&temp);
        if(temp<maxs){
            maxs=temp;
            min=i;
        }
    }
    int a[min+1];
    a[min]=maxs;

/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
  
printf("第%d个数最小=%d\n",min+1,a[min]);  
 return 0;  
}  
  
/* PRESET CODE END - NEVER TOUCH CODE ABOVE */
