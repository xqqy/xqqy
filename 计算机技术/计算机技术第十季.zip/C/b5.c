#include<stdio.h>
int main(int argc, char const *argv[])
{
    int n;
    scanf("%d",&n);
    for (int i = 2; i < n; i++)
    {
        if(n%i==0){
            puts("No");
            return 0;
        }
    }
    puts("Yes");
    return 0;
}
