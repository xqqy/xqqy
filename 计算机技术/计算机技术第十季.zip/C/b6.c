#include <stdio.h>
#include<math.h>
int main(int argc, char const *argv[])
{
    int a, b, n;
    scanf("%d%d%d", &b, &a, &n);
    if (n == 1)
    {
        printf("%d,\n", a);
        printf("sum=%d\n", a);
        return 0;
    }
    if (n == 2)
    {
        printf("%d,%d%d,\n", a, a, b);
        printf("sum=%d\n", a * 11 + b);
        return 0;
    }

    int sum=a * 11 + b;
    printf("%d,%d%d,", a, a, b);
    for (int i = 2; i < n; i++)
    {
        printf("%d",a);
        for (int t = 0; t < i-1; t++)
        {
            printf("%d",b);
            sum += (int)b*pow(10,t+1);
        }
        printf("%d,",a);
        sum += (int)a*pow(10,i)+a;
    }
    printf("\nsum=%d\n",sum);
    return 0;
}
