// Powered by xqqy

#include <stdio.h>
int main(int argc, char const* argv[]) {
    int i,t;
    for (i = 0; i < 10; i++)
    {
        for (t = 0; t < 10; t++)
        {
            if ((30+i)*6237==(t*10+3)*3564)
            {
                printf("%d,%d\n",i,t);
                return 0;
            }
            
        }
        
    }
    
    return -1;
}