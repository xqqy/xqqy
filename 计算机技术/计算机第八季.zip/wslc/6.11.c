// Powered by xqqy
#include <stdio.h>
int main() {
    int  n;
    float ans,input;
    scanf("%d",&n);
    for (int i = 0; i < n; i++)
    {
        scanf("%f",&input);
        ans+=(float)input/n;
    }
    printf("%.2f\n",ans);
    return 0;
}