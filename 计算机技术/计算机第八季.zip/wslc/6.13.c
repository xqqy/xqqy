// Powered by xqqy
#include<stdio.h>
#define dou(x) ((x)*(x))
int iszhi(int i)    
{    
    int t;    
    for (t = 2; t < i; t++)    
    {    
        if (!(i % t))  
        { //不是质数    
            return 0;    
        }    
    }    
    return 1;    
} 
int main(int argc, char const *argv[])
{
    int a,ans=0;
    scanf("%d",&a);
    for (unsigned int i = 3; i <= a; i++)
    {
        if(iszhi(i))
            ans += dou(i);
    }
    printf("%d\n",ans);
    return 0;
}
