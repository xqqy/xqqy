/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

#include <stdio.h>
int main() {
  int a[100], i, min, n; // max记录最大数的值
  scanf("%d", &n);
  for (i = 0; i < n; i++) /*输入n个数并保存到数组a*/
    scanf("%d", &a[i]);

  /* PRESET CODE END - NEVER TOUCH CODE ABOVE */

//Powered by xqqy

int minnum=2147483647;

for (int i = 0; i < n; i++)
{
    if(a[i]<=minnum){
        min=i;
        minnum=a[i];
    }
}



  /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

printf("min=%d,位于第%d个\n",a[min],min+1);   
return 0;  
}  

/* PRESET CODE END - NEVER TOUCH CODE ABOVE */