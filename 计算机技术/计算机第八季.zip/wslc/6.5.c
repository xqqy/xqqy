// Powered by xqqy

#include <stdio.h>
int isrun(int a);
int main(int argc, char const *argv[]) {
  char *norun[] = {"31天", "28天", "31天", "30天", "31天", "30天",
                   "31天", "31天", "30天", "31天", "30天", "31天"};
  char *run[] = {"31天", "29天", "31天", "30天", "31天", "30天",
                 "31天", "31天", "30天", "31天", "30天", "31天"};
  int year, month;
  scanf("%d%d", &year, &month);
  if (month > 12 || month < 0 || year < 0) {
    printf("错误！数据不合法");
    return -1;
  } else
    month--;
  if (isrun(year))
    printf("%s\n", run[month]);
  else
    printf("%s\n", norun[month]);
  return 0;
}

int isrun(int a) {
  if (!(a % 400))
    return 1;
  else if (!(a % 100))
    return 0;
  else if (!(a % 4))
    return 1;
  else
    return 0;
}