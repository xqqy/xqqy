/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

#include <stdio.h>
int main() {
  int n, a[30] = {1, 1}, i, s = 0;
  scanf("%d", &n);

  /* PRESET CODE END - NEVER TOUCH CODE ABOVE */

  // Powered by xqqy
  for (int i = 2; i < n; i++) {
    a[i] = a[i - 1] + a[i - 2];
  }

  /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

  for (i = 0; i < n; i++)  //前n项求和
    s = s + a[i];
  printf("%d\n", s);  //输出和
}

/* PRESET CODE END - NEVER TOUCH CODE ABOVE */