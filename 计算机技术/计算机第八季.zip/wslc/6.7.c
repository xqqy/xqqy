// Powered by xqqy

#include <stdio.h>
int isrun(int a);
int main(int argc, char const *argv[])
{
    int norun[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int run[] = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int *touse;
    int year, month,day;
    scanf("%d%d%d", &year, &month, &day);
    if (month > 12 || month < 0 || year < 0)
    {
        printf("错误！数据不合法");
        return -1;
    }
    if (isrun(year))
        touse = run;
    else
        touse = norun;
    month--;
    int ans=0;
    for (int i = 0; i < month; i++)
    {
        ans+=touse[i];
    }
    printf("第%d天\n",ans+day);
    return 0;
}

  int isrun(int a)
{
    if (!(a % 400))
        return 1;
    else if (!(a % 100))
        return 0;
    else if (!(a % 4))
        return 1;
    else
        return 0;
}