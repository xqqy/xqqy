// Powered by xqqy

#include <stdio.h>
int main(int argc, char const* argv[]) {
    int a = 1, b = 1, n, now = 2, flag = 0;
    scanf("%d", &n);
    if (n == 1) {
        printf("1,");
        return 0;
    }
    else{
        printf("1,1,");
    }
    if (n % 2)
        flag = 1;
    n /= 2;
    for (int i = 1; i < n; i++) {
        a += b;
        b += a;
        printf("%d,%d,",a,b);
        now += 2;
        if(now>=4){
            printf("\n");
            now=0;
        }
    }
    if(flag){
        printf("%d,",a+b);
        now +=1;
    }
    if(now!=0)
        printf("\n");
    return 0;
}