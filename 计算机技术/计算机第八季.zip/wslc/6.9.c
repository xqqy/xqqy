/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

#include <stdio.h>
int main() {
    int n = 0, a[30];  // n表示素数个数，a数组用于存放素数

    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */

    // Powered by xqqy
    int t;

    for (int i = 100; i < 200; i++) {
        for (t = 2; t < i; t++) {
            if (!(i % t)) {  //不是质数
                break;
            }
        }
        a[n]=i;
        if(t==i)
            n++;
        
    }


/* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */

printf("%d个\n%d,%d\n", n, a[9], a[19]);
return 0;
}

/* PRESET CODE END - NEVER TOUCH CODE ABOVE */
