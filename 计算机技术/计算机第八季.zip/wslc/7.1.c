//Powered by xqqy
#include<stdio.h>
int main(int argc, char const *argv[])
{
    float score[7],sum=0.0;
    for (unsigned int i = 0; i < 8; i++)
    {
        scanf("%f",&score[i]);
        sum+=score[i];
    }
    float max=-2147483647.0,min=2147483647.0;
    for (unsigned int i = 0; i < 8; i++)
    {
        if(score[i]>max)
            max=score[i];
        if(score[i]<min)
            min=score[i];
    }
    sum-=max;
    sum-=min;
    printf("%.5f\n",(float)sum/6);
    return 0;
}
