// powered by xqqy
#include <stdio.h>
int ishave(int* a, int num) {
    for (unsigned int i = 0; i <10 ; i++) {
        if (a[i] == num)
            return 1;
    }
    return 0;
}
int main(int argc, char const* argv[]) {
    int a[10], b[10], c[20]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    for (unsigned int i = 0; i < 10; i++) {
        scanf("%d", &a[i]);
    }
    for (unsigned int i = 0; i < 10; i++) {
        scanf("%d", &b[i]);
    }
    int flag = -1, cnum = 0, lastc = 0;
    for (unsigned int i = 0; i < 10; i++) {
        if (a[i] == 0 && flag==-1) {  // 0和数组未定义就引用类似，因此予以排除并单独查找。找到了就记录位置
            for (unsigned int t = 0; t < 10; t++) {
                if (b[t] == 0) {
                    flag = lastc;
                }
            }
            break;
        }
        if (ishave(b, a[i]) && !ishave(c, a[i])) {
            c[cnum] = a[i];
            cnum++; 
            lastc++;
        }
            //printf("\nc[cnum]=%d;cnum=%d;lastc=%d;ishave(b,a[i]):%d;ishave(c,a[i]):%d;a[i]:%d;\n",c[cnum],cnum,lastc,ishave(b,a[i]),ishave(c,a[i]),a[i]);
    }
    if (flag == -1) {
        for (unsigned int i = 0; c[i]; i++)  //一直输出知道C数组不存在了
        {
            printf("%d,", c[i]);
        }
    } else {
        for (unsigned int i = 0; c[i]; i++)  //一直输出知道C数组不存在了
        {
            if (i == flag) {//如果0出现在中间
                printf("0,");
                i--;
                flag=-1;
                continue;
            }
            printf("%d,", c[i]);
        }
    }
    if(flag!=-1){//如果0出现在末尾
        printf("0,");
    }
    printf("\n");
    return 0;
}
