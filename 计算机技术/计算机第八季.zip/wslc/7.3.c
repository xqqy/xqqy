//powered by xqqy
#include<stdio.h>
int iszhi(int i)    
{    //质数判断函数
    int t;    
    for (t = 2; t < i; t++)    
    {    
        if (!(i % t))  
        { //不是质数    
            return 0;    
        }    
    }    
    return 1;    
} 
int main(int argc, char const *argv[])
{
    int a[10];
    for (int i = 0; i < 10; i++)
    {
        scanf("%d",&a[i]);
    }
    
    int num=0,zhi[10];
    for (int i = 0; i < 10; i++)
    {
        if(iszhi(a[i])){
            zhi[num++]=a[i];
        }
    }
    if(num>9){
        printf("%d,%d,\n",zhi[4],zhi[9]);
    }else if(num>4){
        printf("%d,不存在\n",zhi[4]);
    }else{
        printf("不存在,不存在\n");
    }
    
    return 0;
}
