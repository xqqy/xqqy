//powered by xqqy
#include<stdio.h>
int main(int argc, char const *argv[])
{
    int array[11];
    for (int i = 0; i < 10; i++)
    {
        scanf("%d",&array[i]);
    }
    int x;
    scanf("%d",&x);
    for (int i = 9; i >= 0; i--)
    {
        array[i+1]=array[i];
    }
    array[0]=x;
    for (int i = 0; i < sizeof(array)/sizeof(array[0])-1; i++)
    {
        printf("%d ",array[i]);
    }
    printf("%d\n",array[10]);
    return 0;
}
