// powered by xqqy
#include <stdio.h>
#include <stdlib.h>
typedef struct MeowArray //双向链表技术！！!(isfirst和isend更方便喵看它是不是越界！)
{
    struct MeowArray *forward;
    struct MeowArray *back;
    int data;
    int isfirst;
    int isend;
} MeowArray;

int main(int argc, char const *argv[])
{
    MeowArray *node;                               //当前节点
    node = (MeowArray *)malloc(sizeof(MeowArray)); //输入第一个节点
    node->isfirst = 1;
    node->isend = 1;
    scanf("%d", &node->data);

    for (int i = 0; i < 9; i++) // 按顺序输入9项
    {
        MeowArray *forward;
        forward = node;                                //前一个结点
        node = (MeowArray *)malloc(sizeof(MeowArray)); // new一个新节点
        scanf("%d", &node->data);                      //输入数据
        node->forward = forward;                       //更改指针
        forward->back = node;
        node->isfirst = 0; //更改flag
        node->isend = 1;
        forward->isend = 0;
    }

    //获取插入位置的节点
    for (int i = 0; !node->isfirst; i++)
    {                         //获取第一个节点
        node = node->forward; //在上述输入完成后，node为最后一项节点。通过isfirst找到第一个节点
    }

    int pos;
    scanf("%d", &pos); //获取需要插入的位置
    for (int i = 1; i < pos - 1; i++)
    { //从第一个开始数，往后pos个节点。选择pos前一个节点做插入
        node = node->back;
    }

    int num;
    scanf("%d", &num); //获取插入的数量
    if (pos != 1 && !node->isend)
    { //对于往头部插，需要选取第一个节点往前面先插一个；对于往尾巴插， back是空指针

        for (int i = 0; i < num; i++)
        {
            MeowArray *forward = node;
            MeowArray *back = node->back;
            node = (MeowArray *)malloc(sizeof(MeowArray)); // new一个新节点
            scanf("%d", &node->data);
            node->isfirst = 0;
            node->isend = 0;
            //更改指针
            forward->back = node;
            back->forward = node;
            node->forward = forward;
            node->back = back;
        }
    }
    else if (pos == 1)
    { //对于往头插
        MeowArray *forward;
        MeowArray *back = node;
        node = (MeowArray *)malloc(sizeof(MeowArray)); //输入第一个节点
        node->isfirst = 1;
        node->isend = 0;
        scanf("%d", &node->data); //输入第一个节点
        node->back = back;

        for (int i = 0; i < num-1; i++)
        {
            forward = node;
            back = node->back;
            node = (MeowArray *)malloc(sizeof(MeowArray)); // new一个新节点
            scanf("%d", &node->data);
            node->isfirst = 0;
            node->isend = 0;
            //更改指针
            forward->back = node;
            back->forward = node;
            node->forward = forward;
            node->back = back;
        }
    }
    else
    {//末尾节点
        for (int i = 0; i < num; i++) // 按顺序输入9项
        {
            MeowArray *forward;
            forward = node;                                //前一个结点
            node = (MeowArray *)malloc(sizeof(MeowArray)); // new一个新节点
            scanf("%d", &node->data);                      //输入数据
            node->forward = forward;                       //更改指针
            forward->back = node;
            node->isfirst = 0; //更改flag
            node->isend = 1;
            forward->isend = 0;
        }
    }

    //开始输出
    while (!node->isfirst)
    {                         //获取第一个节点
        node = node->forward; //在上述输入完成后，node为最后一项节点。通过isfirst找到第一个节点
    }
    while (!node->isend)
    {
        printf("%d ", node->data);
        node = node->back;
    }
    printf("%d \n", node->data);
    return 0;
}
