//Powered by xqqy
#include<stdio.h>
int main(int argc, char const *argv[])
{
    int array[11];
    for (int i = 0; i < 10; i++)
    {
        scanf("%d",&array[i]);
    }
    
    int input;
    scanf("%d",&input);
    int i;
    for (i = 0; i < 10; i++)
    {
        if(input<array[i]){//开始在这一节点往后挪
            for (int t = 10; t > i; t--)
            {
                array[t]=array[t-1];
            }
            array[i]=input;
            break;
        }
    }
    if(i==10)
        array[10]=input;
    
    for (int i = 0; i < 11; i++)
    {
        printf("%d ",array[i]);
    }
    printf("\n");
    return 0;
}
