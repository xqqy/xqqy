    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
     
    #include<stdio.h>   
    int main()  
    {  
        int i,tmp,list[50],n;  
        scanf("%d",&n);/*输入实际个数*/  
        for(i=0;i<n;i++)/*输入数组元素*/  
           scanf("%d",&list[i]);  
      
    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */  

for (int i = n-1; i > 0; i--)
{
    for (int t = 0; t < i; t++)
    {
        if(list[t]>list[t+1]){
            tmp=list[t];
            list[t]=list[t+1];
            list[t+1]=tmp;
        }
    }
}


    /* PRESET CODE BEGIN - NEVER TOUCH CODE BELOW */  
      
    for(i=0;i<n; i++)//输出排好序的数组元素  
         printf("%d,",list[i]);   
     printf("\n");  
    return 0;  
    }  
      
    /* PRESET CODE END - NEVER TOUCH CODE ABOVE */  