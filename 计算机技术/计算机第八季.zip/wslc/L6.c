//Powered by xqqy

#include<stdio.h>
int main(int argc, char const *argv[])
{
    int ans=0;
    for (int i = 0; i < 10; i++)
    {
        int a;
        scanf("%d",&a);
        if(a>5)
            ans+=1;
    }
    printf("%d\n",ans);
    return 0;
}
